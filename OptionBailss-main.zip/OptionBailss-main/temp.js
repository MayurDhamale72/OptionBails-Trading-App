import { Font } from 'expo';

/* fonts */
export const FontFamily = {
  interSemiBold: "Inter-SemiBold",
  interBold: "Inter-Bold",
  cambayBold: "Cambay-Bold",
  interRegular: "Inter-Regular",
  robotoBold: "Roboto-Bold",
  interMedium: "Inter-Medium",
};
/* font sizes */
export const FontSize = {
  size_sm: 14,
  size_lg: 18,
  size_6xl: 25,
  size_mini: 15,
  size_xl: 20,
  size_3xs: 10,
  size_xs: 12,
  size_4xs_5: 9,
  size_8xs_8: 5,
};
/* Colors */
export const Color = {
  colorGhostwhite: "#f5f6fb",
  colorDarkgray: "#aab2bd",
  colorDarkgray_100: "rgba(170, 178, 189, 0)",
  colorBlack: "#000",
  colorWhite: "#fff",
  colorRoyalblue: "#3f5bd9",
  colorDarkslategray: "#253141",
  colorIndianred: "#d54d4c",
  colorWhitesmoke: "#f5f5f5",
  black2: "#797979",
  black11: "#202020",
  black1: "#1a1a1a",
  green1: "#0f9e3a",
  colorFirebrick_100: "#bc0806",
};
/* Paddings */
export const Padding = {
  p_mini: 15,
  p_5xs: 8,
  p_sm: 14,
  p_7xs: 6,
  p_3xs: 10,
  p_6xs: 7,
  p_xl: 20,
  p_8xs: 5,
};
/* border radiuses */
export const Border = {
  br_9xs: 4,
  br_xs: 12,
  br_12xs_9: 1,
  br_xl: 20,
  br_5xs: 8,
  br_3xs: 10,
};



// Load custom fonts
async function loadCustomFonts() {
  await Font.loadAsync({
    "Inter-SemiBold": require("./assets/fonts/Inter-SemiBold.ttf"),
    "Inter-Bold": require("./assets/fonts/Inter-Bold.ttf"),
    "Cambay-Bold": require("./assets/fonts/Cambay-Bold.ttf"),
    "Inter-Regular": require("./assets/fonts/Inter-Regular.ttf"),
    "Roboto-Bold": require("./assets/fonts/Roboto-Bold.ttf"),
    "Inter-Medium": require("./assets/fonts/Inter-Medium.ttf"),
  });
}


// Call loadCustomFonts function where you initialize your app or before the component renders
loadCustomFonts()
  .then(() => {
    console.log('Custom fonts loaded successfully');
    // Render your app or component
  })
  .catch((error) => {
    console.log('Error loading custom fonts', error);
    // Handle error loading fonts
  });