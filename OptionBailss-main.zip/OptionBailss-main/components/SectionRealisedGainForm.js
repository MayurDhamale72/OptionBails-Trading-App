import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import { FontSize, FontFamily, Color, Padding } from "../GlobalStyles";

const SectionRealisedGainForm = () => {
  return (
    <View style={styles.frameParent}>
      <View style={[styles.frameGroup, styles.frameFlexBox]}>
        <View style={styles.totalPlParent}>
          <Text style={styles.totalPl}>{`Total P&L`}</Text>
          <View style={[styles.positions, styles.text1SpaceBlock]}>
            <Image
              style={styles.positionsChild}
              contentFit="cover"
              source={require("../assets/group-66.png")}
            />
            <Text style={[styles.text, styles.textTypo]}>35000</Text>
          </View>
        </View>
        <View style={styles.parentSpaceBlock}>
          <Text style={styles.totalPl}>Open Positions</Text>
          <Text style={[styles.text1, styles.textTypo]}>05</Text>
        </View>
      </View>
      <View style={[styles.frameContainer, styles.frameFlexBox]}>
        <View style={styles.totalPlParent}>
          <Text style={styles.totalPl}>Unrealised Gain</Text>
          <View style={[styles.positions, styles.text1SpaceBlock]}>
            <Image
              style={styles.positionsChild}
              contentFit="cover"
              source={require("../assets/group-66.png")}
            />
            <Text style={[styles.text, styles.textTypo]}>35000</Text>
          </View>
        </View>
        <View style={[styles.realisedGainParent, styles.parentSpaceBlock]}>
          <Text style={styles.totalPl}>Realised Gain</Text>
          <View style={[styles.positions, styles.text1SpaceBlock]}>
            <Image
              style={styles.positionsChild}
              contentFit="cover"
              source={require("../assets/group-66.png")}
            />
            <Text style={[styles.text, styles.textTypo]}>35000</Text>
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  frameFlexBox: {
    alignItems: "center",
    flexDirection: "row",
  },
  text1SpaceBlock: {
    marginTop: 5,
    alignSelf: "stretch",
  },
  textTypo: {
    fontSize: FontSize.size_4xs_5,
    fontFamily: FontFamily.interRegular,
  },
  parentSpaceBlock: {
    marginLeft: 172,
    flex: 1,
  },
  totalPl: {
    fontSize: FontSize.size_3xs,
    textAlign: "center",
    color: Color.colorBlack,
    fontFamily: FontFamily.interRegular,
  },
  positionsChild: {
    width: 6,
    height: 8,
  },
  text: {
    color: Color.green1,
    marginLeft: 2,
    textAlign: "center",
  },
  positions: {
    alignItems: "center",
    flexDirection: "row",
  },
  totalPlParent: {
    justifyContent: "center",
    flex: 1,
  },
  text1: {
    textAlign: "left",
    marginTop: 5,
    alignSelf: "stretch",
    color: Color.colorBlack,
  },
  frameGroup: {
    alignSelf: "stretch",
    flexDirection: "row",
  },
  realisedGainParent: {
    justifyContent: "center",
  },
  frameContainer: {
    marginTop: 10,
    alignSelf: "stretch",
    flexDirection: "row",
  },
  frameParent: {
    backgroundColor: Color.colorWhite,
    width: 336,
    padding: Padding.p_3xs,
    marginTop: 8,
  },
});

export default SectionRealisedGainForm;
