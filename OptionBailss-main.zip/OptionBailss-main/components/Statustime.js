import React, { useMemo } from "react";
import { Text, StyleSheet, View } from "react-native";
import { FontSize, FontFamily } from "../GlobalStyles";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const Statustime = ({ statustimePosition, h21mColor }) => {
  const statustimeStyle = useMemo(() => {
    return {
      ...getStyleValue("position", statustimePosition),
    };
  }, [statustimePosition]);

  const h21mStyle = useMemo(() => {
    return {
      ...getStyleValue("color", h21mColor),
    };
  }, [h21mColor]);

  return (
    <View style={[styles.statustime, statustimeStyle]}>
      <Text style={[styles.h21m, h21mStyle]}>11h 21m</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  h21m: {
    fontSize: FontSize.size_3xs,
    fontWeight: "500",
    fontFamily: FontFamily.interMedium,
    color: "#b40000",
    textAlign: "center",
  },
  statustime: {
    width: 72,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
});

export default Statustime;
