import React, { useMemo } from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View, ImageSourcePropType } from "react-native";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const Property1on1 = ({ group59, property1onPosition }) => {
  const property1on1Style = useMemo(() => {
    return {
      ...getStyleValue("position", property1onPosition),
    };
  }, [property1onPosition]);

  return (
    <View style={[styles.property1on, property1on1Style]}>
      <Image
        style={styles.property1onChild}
        contentFit="cover"
        source={group59}
      />
      <Text style={styles.home}>HOME</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  property1onChild: {
    width: 20,
    height: 18,
  },
  home: {
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.interRegular,
    color: Color.colorRoyalblue,
    textAlign: "center",
    marginTop: 5,
  },
  property1on: {
    alignItems: "center",
  },
});

export default Property1on1;
