import * as React from "react";
import { StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import { Border, Color } from "../GlobalStyles";

const Back = () => {
  return (
    <View style={styles.back}>
      <View style={styles.backChild} />
      <Image
        style={styles.outlineIcon}
        contentFit="cover"
        source={require("../assets/outline.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  backChild: {
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    borderRadius: Border.br_9xs,
    backgroundColor: Color.colorWhite,
    position: "absolute",
  },
  outlineIcon: {
    height: "35%",
    width: "17.5%",
    top: "32.5%",
    right: "42.5%",
    bottom: "32.5%",
    left: "40%",
    borderRadius: 1,
    maxWidth: "100%",
    overflow: "hidden",
    maxHeight: "100%",
    position: "absolute",
  },
  back: {
    width: 40,
    height: 40,
  },
});

export default Back;
