import React, { useMemo } from "react";
import { Text, StyleSheet, View, ImageSourcePropType } from "react-native";
import { Image } from "expo-image";
import { FontFamily, Color, FontSize, Border, Padding } from "../GlobalStyles";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const PortfolioContainer = ({
  group68,
  group66,
  group661,
  group662,
  investment,
  group663,
  group664,
  prop,
  thisGamesProfitMarginTop,
}) => {
  const portfolioObj1Style = useMemo(() => {
    return {
      ...getStyleValue("marginTop", thisGamesProfitMarginTop),
    };
  }, [thisGamesProfitMarginTop]);

  return (
    <View style={[styles.portfolioobj1, portfolioObj1Style]}>
      <View style={styles.watchlistObj1Wrapper}>
        <View style={[styles.watchlistObj1, styles.avgParentFlexBox]}>
          <View style={[styles.indVsEngParent, styles.avgParentFlexBox]}>
            <Text style={[styles.indVsEng, styles.text6Typo]}>IND Vs ENG</Text>
            <Text style={[styles.nov202310500Ce, styles.text6Typo]}>
              30-Nov-2023 10500 CE
            </Text>
          </View>
          <View style={styles.price}>
            <View style={[styles.parent, styles.ltpFlexBox]}>
              <Text style={[styles.text, styles.textTypo1]}>15700</Text>
              <Image
                style={styles.frameChild}
                contentFit="cover"
                source={group68}
              />
            </View>
            <View style={[styles.group, styles.groupFlexBox]}>
              <Text style={[styles.text1, styles.textTypo]}>+3.20</Text>
              <Text style={[styles.text2, styles.textTypo]}>(+0.02%)</Text>
            </View>
          </View>
        </View>
      </View>
      <View style={[styles.frameParent, styles.frameParentSpaceBlock]}>
        <View style={[styles.avgParent, styles.avgParentFlexBox]}>
          <Text style={[styles.indVsEng, styles.text6Typo]}>Avg</Text>
          <View style={[styles.avg1, styles.avgFlexBox]}>
            <Image
              style={styles.avgChild}
              contentFit="cover"
              source={group66}
            />
            <Text style={[styles.text3, styles.textTypo1]}>35000</Text>
          </View>
        </View>
        <View style={[styles.ltp, styles.ltpFlexBox]}>
          <Text style={[styles.indVsEng, styles.text6Typo]}>Ltp</Text>
          <View style={[styles.avg2, styles.avgFlexBox]}>
            <Image
              style={styles.avgChild}
              contentFit="cover"
              source={group661}
            />
            <Text style={[styles.text3, styles.textTypo1]}>780</Text>
            <Text style={[styles.text3, styles.textTypo1]}>(+1.33)</Text>
          </View>
        </View>
      </View>
      <View style={[styles.frameParent, styles.frameParentSpaceBlock]}>
        <View style={[styles.avgParent, styles.avgParentFlexBox]}>
          <Text style={[styles.indVsEng, styles.text6Typo]}>Lots</Text>
          <Text style={[styles.text6, styles.text6Typo]}>1000</Text>
        </View>
        <View style={[styles.totalProfit, styles.groupFlexBox]}>
          <Text style={[styles.thisGamesProfit, styles.textTypo1]}>
            This Games Profit
          </Text>
          <View style={[styles.avg3, styles.avgParentFlexBox]}>
            <Image
              style={styles.avgChild}
              contentFit="cover"
              source={group662}
            />
            <Text style={[styles.text3, styles.textTypo1]}>20</Text>
            <Text style={[styles.text3, styles.textTypo1]}>(+1.33)</Text>
          </View>
        </View>
      </View>
      <View style={[styles.portfolioobj1Child, styles.frameParentSpaceBlock]} />
      <View style={[styles.frameParent, styles.frameParentSpaceBlock]}>
        <View style={[styles.invested, styles.avgParentFlexBox]}>
          <Text style={[styles.indVsEng, styles.text6Typo]}>{investment}</Text>
          <View style={[styles.avg1, styles.avgFlexBox]}>
            <Image
              style={styles.avgChild}
              contentFit="cover"
              source={group663}
            />
            <Text style={[styles.text3, styles.textTypo1]}>35000</Text>
          </View>
        </View>
        <View style={[styles.invested, styles.avgParentFlexBox]}>
          <Text style={[styles.indVsEng, styles.text6Typo]}>Current</Text>
          <View style={[styles.avg1, styles.avgFlexBox]}>
            <Image
              style={styles.avgChild}
              contentFit="cover"
              source={group664}
            />
            <Text style={[styles.text3, styles.textTypo1]}>{prop}</Text>
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  avgParentFlexBox: {
    flexDirection: "row",
    alignItems: "center",
  },
  text6Typo: {
    textAlign: "left",
    fontFamily: FontFamily.interRegular,
    color: Color.colorBlack,
  },
  ltpFlexBox: {
    justifyContent: "flex-end",
    alignItems: "center",
    flexDirection: "row",
  },
  textTypo1: {
    textAlign: "center",
    fontFamily: FontFamily.interRegular,
  },
  groupFlexBox: {
    justifyContent: "space-between",
    flexDirection: "row",
  },
  textTypo: {
    fontSize: FontSize.size_8xs_8,
    textAlign: "left",
    color: Color.colorBlack,
    fontFamily: FontFamily.interRegular,
  },
  frameParentSpaceBlock: {
    marginTop: 8,
    alignSelf: "stretch",
  },
  avgFlexBox: {
    marginLeft: 5,
    alignItems: "center",
    flexDirection: "row",
    alignSelf: "stretch",
  },
  indVsEng: {
    fontSize: FontSize.size_xs,
  },
  nov202310500Ce: {
    width: 168,
    marginLeft: 10,
    fontSize: FontSize.size_xs,
  },
  indVsEngParent: {
    width: 251,
    alignItems: "center",
  },
  text: {
    color: Color.green1,
    fontSize: FontSize.size_4xs_5,
  },
  frameChild: {
    width: 7,
    height: 6,
    marginLeft: 3,
  },
  parent: {
    alignSelf: "stretch",
  },
  text1: {
    width: 15,
  },
  text2: {
    flex: 1,
  },
  group: {
    width: 36,
    marginTop: 1,
    alignItems: "center",
  },
  price: {
    height: 17,
    alignItems: "flex-end",
    flex: 1,
    justifyContent: "center",
  },
  watchlistObj1: {
    alignItems: "center",
    alignSelf: "stretch",
  },
  watchlistObj1Wrapper: {
    justifyContent: "center",
    alignSelf: "stretch",
  },
  avgChild: {
    width: 6,
    height: 8,
  },
  text3: {
    marginLeft: 2,
    fontSize: FontSize.size_4xs_5,
    color: Color.colorBlack,
    textAlign: "center",
  },
  avg1: {
    width: 39,
  },
  avgParent: {
    flex: 1,
    alignItems: "center",
  },
  avg2: {
    width: 54,
  },
  ltp: {
    flex: 1,
  },
  frameParent: {
    justifyContent: "space-between",
    flexDirection: "row",
  },
  text6: {
    marginLeft: 8,
    fontSize: FontSize.size_4xs_5,
  },
  thisGamesProfit: {
    width: 117,
    color: Color.colorBlack,
    textAlign: "center",
    fontSize: FontSize.size_xs,
  },
  avg3: {
    width: 49,
    alignItems: "center",
    alignSelf: "stretch",
  },
  totalProfit: {
    flex: 1,
    alignItems: "center",
  },
  portfolioobj1Child: {
    backgroundColor: Color.colorDarkgray,
    height: 1,
  },
  invested: {
    alignItems: "center",
  },
  portfolioobj1: {
    borderRadius: Border.br_5xs,
    backgroundColor: Color.colorWhite,
    width: 339,
    padding: Padding.p_8xs,
    marginTop: 10,
  },
});

export default PortfolioContainer;
