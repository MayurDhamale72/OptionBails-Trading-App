import React, { useMemo } from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View, ImageSourcePropType } from "react-native";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const Property1off = ({
  dimensionsCode,
  property1offPosition,
  onCricketPress,
}) => {
  const property1offStyle = useMemo(() => {
    return {
      ...getStyleValue("position", property1offPosition),
    };
  }, [property1offPosition]);

  return (
    <View
      style={[styles.property1off, property1offStyle]}
      onPress={onCricketPress}
    >
      <Image
        style={styles.vectorIcon}
        contentFit="cover"
        source={dimensionsCode}
      />
      <Text style={styles.cricket}>Cricket</Text>
      <View style={styles.property1offChild} />
    </View>
  );
};

const styles = StyleSheet.create({
  vectorIcon: {
    width: 20,
    height: 20,
  },
  cricket: {
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.interRegular,
    color: Color.colorDarkgray,
    textAlign: "center",
    marginTop: 3,
  },
  property1offChild: {
    backgroundColor: Color.colorDarkgray_100,
    width: 34,
    height: 3,
    marginTop: 3,
  },
  property1off: {
    alignItems: "center",
  },
});

export default Property1off;
