import * as React from "react";
import { Text, StyleSheet, View, TouchableOpacity } from "react-native";
import GroupComponent from "./GroupComponent";
import { FontSize, Color, FontFamily, Border } from "../GlobalStyles";

import HomeScreen from "../screens/MainHomeScreen";

const VerifyCodeForm = (navigation) => {
  return (
    <View style={styles.verifyCodeParent}>
      <Text style={styles.verifyCode}>Verify Code</Text>
      <Text
        style={[styles.theConfirmationCode, styles.passwordTypo]}
      >{'The confirmation codesent via email'}</Text>
      <View style={styles.instanceParent}>
        <GroupComponent
          carNumber="3"
          groupViewAlignSelf="stretch"
          groupViewFlex={1}
          groupViewMarginLeft="unset"
        />
        <GroupComponent
          carNumber="4"
          groupViewAlignSelf="stretch"
          groupViewFlex={1}
          groupViewMarginLeft={15}
        />
        <GroupComponent
          carNumber="8"
          groupViewAlignSelf="stretch"
          groupViewFlex={1}
          groupViewMarginLeft={15}
        />
        <GroupComponent
          carNumber="3"
          groupViewAlignSelf="stretch"
          groupViewFlex={1}
          groupViewMarginLeft={15}
        />
      </View>
      <Text style={[styles.forgotPassword, styles.passwordTypo]}>
        Forgot Password?
      </Text>

      < Buttonr navigation={navigation} />

      
    </View>
  );
};

const Buttonr = ({ navigation }) => {
  return (
    <View style={styles.largeBtnParent}>
        <View style={[styles.largeBtn, styles.largePosition]}>
          <View style={[styles.largeBtnChild, styles.largePosition]} />
        </View>
        <TouchableOpacity onPress={() => navigation.navigate('HomeScreen')}>
          <Text style={[styles.resetPassword, styles.largePosition]}>
            Reset Password
          </Text>
        </TouchableOpacity>
      </View>
);
};

const styles = StyleSheet.create({
  passwordTypo: {
    fontSize: FontSize.size_sm,
    textAlign: "center",
  },
  largePosition: {
    left: "50%",
    top: "50%",
    position: "absolute",
  },
  verifyCode: {
    fontSize: FontSize.size_6xl,
    color: Color.colorBlack,
    textAlign: "center",
    fontFamily: FontFamily.interSemiBold,
    fontWeight: "600",
  },
  theConfirmationCode: {
    color: Color.colorDarkgray,
    marginTop: 42,
    fontFamily: FontFamily.interSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_sm,
  },
  instanceParent: {
    width: 297,
    height: 62,
    flexDirection: "row",
    marginTop: 42,
    alignItems: "center",
  },
  forgotPassword: {
    color: Color.colorDarkslategray,
    marginTop: 42,
    fontFamily: FontFamily.interSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_sm,
  },
  largeBtnChild: {
    borderRadius: Border.br_9xs,
    backgroundColor: Color.colorRoyalblue,
    marginLeft: -150,
    marginTop: -29,
    left: "50%",
    top: "50%",
    height: 58,
    width: 300,
  },
  largeBtn: {
    marginLeft: -150,
    marginTop: -29,
    left: "50%",
    top: "50%",
    height: 58,
    width: 300,
  },
  resetPassword: {
    marginTop: 15,
    marginLeft: -55,
    fontWeight: "700",
    fontFamily: FontFamily.interBold,
    color: Color.colorWhite,
    fontSize: FontSize.size_sm,
    textAlign: "center",
  },
  largeBtnParent: {
    height: 58,
    width: 300,
    marginTop: 42,
  },
  verifyCodeParent: {
    top: 182,
    left: 30,
    justifyContent: "center",
    alignItems: "center",
    position: "absolute",
  },
});

export default VerifyCodeForm;
