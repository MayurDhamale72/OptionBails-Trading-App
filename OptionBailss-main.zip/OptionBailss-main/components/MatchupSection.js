import React, { useMemo } from "react";
import { Text, StyleSheet, View, ImageSourcePropType } from "react-native";
import { Image } from "expo-image";
import Property1mega from "./Property1mega";
import { Padding, Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const MatchupSection = ({
  eNG,
  iNDVsENG,
  group68,
  iND,
  majesticonstShirtLine,
  propAlignSelf,
}) => {
  const indexStyle = useMemo(() => {
    return {
      ...getStyleValue("alignSelf", propAlignSelf),
    };
  }, [propAlignSelf]);

  return (
    <View style={[styles.frameWrapper, styles.match1Layout]}>
      <View style={styles.frameParent}>
        <View style={styles.frameGroup}>
          <View style={[styles.engVsAusParent, styles.wrapperParentFlexBox]}>
            <Text style={styles.engVsAus}>ENG vs AUS</Text>
            <Image
              style={styles.bxbellPlusIcon}
              contentFit="cover"
              source={require("../assets/bxbellplus.png")}
            />
          </View>
          <View style={[styles.vectorWrapper, styles.wrapperParentFlexBox]}>
            <Image
              style={styles.frameChild}
              contentFit="cover"
              source={require("../assets/vector-3.png")}
            />
          </View>
        </View>
        <View style={styles.frameContainer}>
          <View style={styles.frameView}>
            <View style={[styles.englandParent, styles.wrapperParentFlexBox]}>
              <Text style={[styles.england, styles.englandTypo]}>England</Text>
              <Text style={[styles.australia, styles.englandTypo]}>
                AUSTRALIA
              </Text>
            </View>
            <View style={[styles.match1, styles.match1Layout]}>
              <View style={styles.groupParent}>
                <Image
                  style={styles.frameItemLayout}
                  contentFit="cover"
                  source={require("../assets/group-82.png")}
                />
                <Text style={[styles.eng, styles.engTypo]}>{eNG}</Text>
              </View>
              <View style={[styles.index, indexStyle]}>
                <Text style={[styles.indVsEng, styles.textTypo1]}>
                  {iNDVsENG}
                </Text>
                <View style={styles.frameView}>
                  <View style={styles.parent}>
                    <Text style={[styles.text, styles.textTypo1]}>15700</Text>
                    <Image
                      style={styles.frameInner}
                      contentFit="cover"
                      source={group68}
                    />
                  </View>
                  <View style={styles.group}>
                    <Text style={[styles.text1, styles.textTypo]}>+3.20</Text>
                    <Text style={[styles.text2, styles.textTypo]}>
                      (+0.02%)
                    </Text>
                  </View>
                </View>
              </View>
              <View style={styles.groupParent}>
                <Text style={styles.engTypo}>{iND}</Text>
                <Image
                  style={[styles.groupIcon, styles.frameItemLayout]}
                  contentFit="cover"
                  source={require("../assets/group-83.png")}
                />
              </View>
            </View>
          </View>
          <View style={[styles.frameWrapper1, styles.wrapperParentFlexBox]}>
            <View style={styles.teamOrMegaParent}>
              <Property1mega property1megaPosition="unset" />
              <View style={styles.groupParent}>
                <Image
                  style={styles.bxtvIcon}
                  contentFit="cover"
                  source={require("../assets/bxtv.png")}
                />
                <Image
                  style={styles.majesticonstShirtLine}
                  contentFit="cover"
                  source={majesticonstShirtLine}
                />
              </View>
            </View>
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  match1Layout: {
    width: 336,
    marginTop: 8,
  },
  wrapperParentFlexBox: {
    paddingHorizontal: Padding.p_sm,
    alignItems: "center",
    alignSelf: "stretch",
  },
  englandTypo: {
    color: Color.black11,
    fontFamily: FontFamily.interRegular,
    fontSize: FontSize.size_xs,
  },
  engTypo: {
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
    color: Color.black11,
    textAlign: "left",
    fontSize: FontSize.size_xs,
  },
  textTypo1: {
    textAlign: "center",
    fontSize: FontSize.size_4xs_5,
    fontFamily: FontFamily.interRegular,
  },
  textTypo: {
    fontSize: FontSize.size_8xs_8,
    color: Color.colorBlack,
    textAlign: "left",
    fontFamily: FontFamily.interRegular,
  },
  frameItemLayout: {
    height: 24,
    width: 36,
  },
  engVsAus: {
    color: Color.black2,
    textAlign: "left",
    fontFamily: FontFamily.interRegular,
    fontSize: FontSize.size_xs,
  },
  bxbellPlusIcon: {
    width: 20,
    height: 20,
    overflow: "hidden",
  },
  engVsAusParent: {
    paddingTop: Padding.p_6xs,
    justifyContent: "space-between",
    flexDirection: "row",
  },
  frameChild: {
    maxWidth: "100%",
    maxHeight: "100%",
    width: "100%",
    overflow: "hidden",
    alignSelf: "stretch",
  },
  vectorWrapper: {
    height: 13,
    paddingVertical: Padding.p_3xs,
    justifyContent: "space-between",
  },
  frameGroup: {
    alignItems: "center",
    alignSelf: "stretch",
  },
  england: {
    textAlign: "left",
  },
  australia: {
    textAlign: "right",
  },
  englandParent: {
    paddingVertical: 0,
    justifyContent: "space-between",
    flexDirection: "row",
  },
  eng: {
    marginLeft: 6,
  },
  groupParent: {
    flexDirection: "row",
    alignItems: "center",
  },
  indVsEng: {
    color: Color.colorBlack,
    textAlign: "center",
    fontSize: FontSize.size_4xs_5,
  },
  text: {
    color: Color.green1,
    textAlign: "center",
    fontSize: FontSize.size_4xs_5,
  },
  frameInner: {
    width: 7,
    height: 6,
    marginLeft: 3,
  },
  parent: {
    flexDirection: "row",
    alignItems: "center",
    alignSelf: "stretch",
  },
  text1: {
    width: 15,
  },
  text2: {
    flex: 1,
  },
  group: {
    marginTop: 1,
    width: 36,
    justifyContent: "space-between",
    flexDirection: "row",
    alignItems: "center",
  },
  frameView: {
    alignSelf: "stretch",
  },
  index: {
    width: 48,
  },
  groupIcon: {
    marginLeft: 6,
  },
  match1: {
    height: 44,
    justifyContent: "space-between",
    flexDirection: "row",
    alignItems: "center",
    marginTop: 8,
  },
  bxtvIcon: {
    width: 17,
    height: 17,
    overflow: "hidden",
  },
  majesticonstShirtLine: {
    height: 15,
    marginLeft: 5,
    width: 15,
    overflow: "hidden",
  },
  teamOrMegaParent: {
    justifyContent: "space-between",
    flexDirection: "row",
    alignItems: "center",
    alignSelf: "stretch",
  },
  frameWrapper1: {
    borderBottomRightRadius: Border.br_5xs,
    borderBottomLeftRadius: Border.br_5xs,
    backgroundColor: Color.colorWhitesmoke,
    height: 31,
    paddingVertical: Padding.p_7xs,
    marginTop: 8,
  },
  frameContainer: {
    marginTop: 2,
    alignSelf: "stretch",
  },
  frameParent: {
    borderRadius: Border.br_5xs,
    backgroundColor: Color.colorWhite,
    shadowColor: "rgba(0, 0, 0, 0.09)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 2,
    elevation: 2,
    shadowOpacity: 1,
    alignItems: "center",
    alignSelf: "stretch",
  },
  frameWrapper: {
    marginTop: 8,
  },
});

export default MatchupSection;
