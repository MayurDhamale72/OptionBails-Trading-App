import React, { useMemo } from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View, ImageSourcePropType } from "react-native";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const Property1off3 = ({
  productCode,
  property1offPosition,
  property1offMarginLeft,
  onBaseballPress,
}) => {
  const property1off3Style = useMemo(() => {
    return {
      ...getStyleValue("position", property1offPosition),
      ...getStyleValue("marginLeft", property1offMarginLeft),
    };
  }, [property1offPosition, property1offMarginLeft]);

  return (
    <View
      style={[styles.property1off, property1off3Style]}
      onPress={onBaseballPress}
    >
      <Image
        style={styles.vectorIcon}
        contentFit="cover"
        source={productCode}
      />
      <Text style={styles.baseball}>Baseball</Text>
      <View style={styles.property1offChild} />
    </View>
  );
};

const styles = StyleSheet.create({
  vectorIcon: {
    width: 20,
    height: 20,
  },
  baseball: {
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.interRegular,
    color: Color.colorDarkgray,
    textAlign: "center",
    marginTop: 3,
  },
  property1offChild: {
    backgroundColor: Color.colorDarkgray_100,
    width: 40,
    height: 3,
    marginTop: 3,
  },
  property1off: {
    alignItems: "center",
  },
});

export default Property1off3;
