import React, { useMemo } from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View, ImageSourcePropType } from "react-native";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const Property1off4 = ({
  group60,
  property1offPosition,
  property1offMarginLeft,
  onHokeyPress,
}) => {
  const property1off4Style = useMemo(() => {
    return {
      ...getStyleValue("position", property1offPosition),
      ...getStyleValue("marginLeft", property1offMarginLeft),
    };
  }, [property1offPosition, property1offMarginLeft]);

  return (
    <View
      style={[styles.property1off, property1off4Style]}
      onPress={onHokeyPress}
    >
      <Image
        style={styles.property1offChild}
        contentFit="cover"
        source={group60}
      />
      <Text style={styles.hokey}>Hokey</Text>
      <View style={styles.property1offItem} />
    </View>
  );
};

const styles = StyleSheet.create({
  property1offChild: {
    width: 20,
    height: 20,
  },
  hokey: {
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.interRegular,
    color: Color.colorDarkgray,
    textAlign: "center",
    marginTop: 3,
  },
  property1offItem: {
    backgroundColor: Color.colorDarkgray_100,
    width: 30,
    height: 3,
    marginTop: 3,
  },
  property1off: {
    alignItems: "center",
  },
});

export default Property1off4;
