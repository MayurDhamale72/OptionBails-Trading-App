import React, { useMemo } from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View, ImageSourcePropType, TouchableOpacity } from "react-native";
import { FontSize, FontFamily, Color } from "../GlobalStyles";


const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const Property1off9 = ({
  iconDocStarAlt,
  property1offPosition,
  property1offMarginLeft,
  onWatchlistPress,
}) => {
  const property1off9Style = useMemo(() => {
    return {
      ...getStyleValue("position", property1offPosition),
      ...getStyleValue("marginLeft", property1offMarginLeft),
    };
  }, [property1offPosition, property1offMarginLeft]);

  return (
    <View
      style={[styles.property1off, property1off9Style]}
      onPress={onWatchlistPress}
    >
      <TouchableOpacity>
        <Image
          style={styles.iconDocStarAlt}
          contentFit="cover"
          source={iconDocStarAlt}
        />
        <Text style={styles.watchlist}>WATCHLIST</Text>
      </TouchableOpacity>

    </View>
  );
};

const styles = StyleSheet.create({
  iconDocStarAlt: {
    width: 15,
    height: 18,
    marginLeft: 20
  },
  watchlist: {
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.interRegular,
    color: Color.colorDarkgray,
    textAlign: "center",
    marginTop: 5,
  },
  property1off: {
    alignItems: "center",
  },
});

export default Property1off9;
