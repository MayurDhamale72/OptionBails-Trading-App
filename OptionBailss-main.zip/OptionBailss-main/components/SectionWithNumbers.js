import * as React from "react";
import { Text, StyleSheet, View, ImageSourcePropType } from "react-native";
import { Image } from "expo-image";
import { Padding, FontFamily, FontSize, Color } from "../GlobalStyles";

const SectionWithNumbers = ({
  uniqueIdentifier,
  uniqueIdentifierText,
  dimensionText,
}) => {
  return (
    <View style={[styles.frameParent, styles.frameSpaceBlock]}>
      <View style={[styles.gameIndicesParent, styles.groupParentFlexBox]}>
        <Text style={[styles.gameIndices, styles.textTypo1]}>Game Indices</Text>
        <View style={styles.groupParentFlexBox}>
          <Text style={[styles.viewMore1, styles.textTypo1]}>VIEW MORE</Text>
          <Image
            style={styles.viewMoreChild}
            contentFit="cover"
            source={require("../assets/group-67.png")}
          />
        </View>
      </View>
      <View style={[styles.frameGroup, styles.groupParentFlexBox]}>
        <View>
          <View style={styles.indVsEngParent}>
            <Text style={[styles.gameIndices, styles.textTypo1]}>
              IND Vs ENG
            </Text>
            <View style={styles.indVsEngParent}>
              <View style={[styles.parent, styles.groupParentFlexBox]}>
                <Text style={[styles.text, styles.textTypo1]}>15700</Text>
                <Image
                  style={styles.frameChild}
                  contentFit="cover"
                  source={uniqueIdentifier}
                />
              </View>
              <View style={[styles.group, styles.groupParentFlexBox]}>
                <Text style={[styles.text1, styles.textTypo]}>+3.20</Text>
                <Text style={[styles.text2, styles.textTypo]}>(+0.02%)</Text>
              </View>
            </View>
          </View>
        </View>
        <View style={styles.frameItem} />
        <View>
          <View style={styles.indVsEngParent}>
            <Text style={[styles.gameIndices, styles.textTypo1]}>
              IND Vs ENG
            </Text>
            <View style={styles.indVsEngParent}>
              <View style={[styles.parent, styles.groupParentFlexBox]}>
                <Text style={[styles.text, styles.textTypo1]}>15700</Text>
                <Image
                  style={styles.frameChild}
                  contentFit="cover"
                  source={uniqueIdentifierText}
                />
              </View>
              <View style={[styles.group, styles.groupParentFlexBox]}>
                <Text style={[styles.text1, styles.textTypo]}>+3.20</Text>
                <Text style={[styles.text2, styles.textTypo]}>(+0.02%)</Text>
              </View>
            </View>
          </View>
        </View>
        <View style={styles.frameItem} />
        <View>
          <View style={styles.indVsEngParent}>
            <Text style={[styles.gameIndices, styles.textTypo1]}>
              AUS Vs SA
            </Text>
            <View style={styles.indVsEngParent}>
              <View style={[styles.parent, styles.groupParentFlexBox]}>
                <Text style={[styles.text6, styles.textTypo1]}>11340</Text>
                <Image
                  style={styles.frameChild}
                  contentFit="cover"
                  source={dimensionText}
                />
              </View>
              <View style={[styles.group, styles.groupParentFlexBox]}>
                <Text style={[styles.text1, styles.textTypo]}>-5.80</Text>
                <Text style={[styles.text2, styles.textTypo]}>(-3.52%)</Text>
              </View>
            </View>
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  frameSpaceBlock: {
    padding: Padding.p_3xs,
    justifyContent: "space-between",
  },
  groupParentFlexBox: {
    flexDirection: "row",
    alignItems: "center",
  },
  textTypo1: {
    textAlign: "center",
    fontFamily: FontFamily.interRegular,
    fontSize: FontSize.size_4xs_5,
  },
  textTypo: {
    textAlign: "left",
    fontSize: FontSize.size_8xs_8,
    color: Color.colorBlack,
    fontFamily: FontFamily.interRegular,
  },
  gameIndices: {
    color: Color.colorBlack,
    textAlign: "center",
    fontFamily: FontFamily.interRegular,
    fontSize: FontSize.size_4xs_5,
  },
  viewMore1: {
    color: Color.colorRoyalblue,
    fontFamily: FontFamily.interRegular,
    fontSize: FontSize.size_4xs_5,
    textAlign: "center",
  },
  viewMoreChild: {
    width: 4,
    height: 7,
    marginLeft: 4,
  },
  gameIndicesParent: {
    alignSelf: "stretch",
    justifyContent: "space-between",
    flexDirection: "row",
  },
  text: {
    color: Color.green1,
    fontFamily: FontFamily.interRegular,
    fontSize: FontSize.size_4xs_5,
    textAlign: "center",
  },
  frameChild: {
    width: 7,
    height: 6,
    marginLeft: 3,
  },
  parent: {
    alignSelf: "stretch",
  },
  text1: {
    width: 15,
  },
  text2: {
    flex: 1,
  },
  group: {
    width: 36,
    marginTop: 1,
    justifyContent: "space-between",
    flexDirection: "row",
  },
  indVsEngParent: {
    alignSelf: "stretch",
  },
  frameItem: {
    backgroundColor: Color.colorDarkgray,
    width: 3,
    height: 30,
  },
  text6: {
    color: Color.colorFirebrick_100,
    fontFamily: FontFamily.interRegular,
    fontSize: FontSize.size_4xs_5,
    textAlign: "center",
  },
  frameGroup: {
    borderStyle: "solid",
    borderColor: Color.colorDarkgray,
    borderWidth: 0.5,
    alignSelf: "stretch",
    padding: Padding.p_3xs,
    justifyContent: "space-between",
  },
  frameParent: {
    backgroundColor: Color.colorWhite,
    width: 336,
    height: 90,
    marginTop: 8,
    alignItems: "center",
    padding: Padding.p_3xs,
  },
});

export default SectionWithNumbers;
