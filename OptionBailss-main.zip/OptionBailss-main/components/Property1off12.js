import React, { useMemo } from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View, ImageSourcePropType } from "react-native";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const Property1off12 = ({
  iconProfileCircled,
  property1offPosition,
  property1offMarginLeft,
}) => {
  const property1off12Style = useMemo(() => {
    return {
      ...getStyleValue("position", property1offPosition),
      ...getStyleValue("marginLeft", property1offMarginLeft),
    };
  }, [property1offPosition, property1offMarginLeft]);

  return (
    <View style={[styles.property1off, property1off12Style]}>
      <Image
        style={styles.iconProfileCircled}
        contentFit="cover"
        source={iconProfileCircled}
      />
      <Text style={styles.account}>ACCOUNT</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  iconProfileCircled: {
    width: 18,
    height: 18,
  },
  account: {
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.interRegular,
    color: Color.colorDarkgray,
    textAlign: "center",
    marginTop: 5,
  },
  property1off: {
    alignItems: "center",
  },
});

export default Property1off12;
