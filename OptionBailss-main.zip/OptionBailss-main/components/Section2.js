import React, { useMemo } from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View, ImageSourcePropType } from "react-native";
import Property1off9 from "./Property1off9";
import Property1off10 from "./Property1off10";
import Property1off12 from "./Property1off12";
import { FontFamily, FontSize, Color, Padding } from "../GlobalStyles";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const Section2 = ({
  group59,
  iconDocStarAlt,
  wallet,
  iconNotes,
  iconProfileCircled,
  propColor,
  propColor1,
}) => {
  const hOMEStyle = useMemo(() => {
    return {
      ...getStyleValue("color", propColor),
    };
  }, [propColor]);

  const oRDERSStyle = useMemo(() => {
    return {
      ...getStyleValue("color", propColor1),
    };
  }, [propColor1]);

  return (
    <View style={styles.homeParent}>
      <View style={styles.home}>
        <Image style={styles.homeChild} contentFit="cover" source={group59} />
        <Text style={[styles.home1, styles.home1Typo, hOMEStyle]}>HOME</Text>
      </View>
      <Property1off9
        iconDocStarAlt={require("../assets/-icon-doc-star-alt.png")}
        property1offPosition="unset"
        property1offMarginLeft={25}
      />
      <Property1off10
        wallet={require("../assets/wallet.png")}
        property1offPosition="unset"
        property1offMarginLeft={25}
      />
      <View style={styles.orders}>
        <Image style={styles.iconNotes} contentFit="cover" source={iconNotes} />
        <Text style={[styles.orders1, styles.home1Typo, oRDERSStyle]}>
          ORDERS
        </Text>
      </View>
      <Property1off12
        iconProfileCircled={require("../assets/-icon-profile-circled.png")}
        property1offPosition="unset"
        property1offMarginLeft={25}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  home1Typo: {
    marginTop: 5,
    textAlign: "center",
    fontFamily: FontFamily.interRegular,
    fontSize: FontSize.size_3xs,
  },
  homeChild: {
    width: 20,
    height: 18,
  },
  home1: {
    color: Color.colorDarkgray,
  },
  home: {
    alignItems: "center",
  },
  iconNotes: {
    width: 14,
    height: 18,
  },
  orders1: {
    color: Color.colorRoyalblue,
  },
  orders: {
    marginLeft: 25,
    alignItems: "center",
  },
  homeParent: {
    alignSelf: "stretch",
    backgroundColor: Color.colorWhite,
    flexDirection: "row",
    justifyContent: "center",
    paddingHorizontal: 0,
    paddingVertical: Padding.p_mini,
    alignItems: "center",
  },
});

export default Section2;
