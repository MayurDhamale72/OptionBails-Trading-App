import * as React from "react";
import { Text, StyleSheet, View, ImageSourcePropType } from "react-native";
import { Image } from "expo-image";
import Statustime from "./Statustime";
import Property1mega from "./Property1mega";
import { Color, Border, Padding, FontFamily, FontSize } from "../GlobalStyles";

const Section = ({
  group81,
  majesticonstShirtLine,
  majesticonstShirtLine1,
}) => {
  return (
    <View style={styles.frameParent}>
      <View style={[styles.frameGroup, styles.frameShadowBox]}>
        <View style={styles.frameContainer}>
          <View style={[styles.engVsAusParent, styles.wrapperParentFlexBox]}>
            <Text style={styles.engVsAus}>ENG vs AUS</Text>
            <Image
              style={styles.bxbellPlusIcon}
              contentFit="cover"
              source={require("../assets/bxbellplus.png")}
            />
          </View>
          <View style={[styles.vectorWrapper, styles.wrapperParentFlexBox]}>
            <Image
              style={styles.frameChild}
              contentFit="cover"
              source={require("../assets/vector-3.png")}
            />
          </View>
        </View>
        <View style={styles.frameView}>
          <View style={styles.frameParent1}>
            <View style={[styles.englandParent, styles.wrapperParentFlexBox]}>
              <Text style={[styles.england, styles.englandTypo]}>England</Text>
              <Text style={[styles.australia, styles.englandTypo]}>
                AUSTRALIA
              </Text>
            </View>
            <View style={styles.frameParent2}>
              <View style={styles.groupParent}>
                <Image
                  style={styles.frameLayout}
                  contentFit="cover"
                  source={group81}
                />
                <Text style={[styles.eng, styles.engTypo]}>ENG</Text>
              </View>
              <Statustime statustimePosition="unset" h21mColor="#d54d4c" />
              <View style={styles.groupParent}>
                <Text style={styles.engTypo}>IND</Text>
                <Image
                  style={[styles.frameInner, styles.frameLayout]}
                  contentFit="cover"
                  source={require("../assets/group-83.png")}
                />
              </View>
            </View>
          </View>
          <View style={[styles.frameWrapper, styles.wrapperParentFlexBox]}>
            <View style={styles.teamOrMegaParent}>
              <Property1mega property1megaPosition="unset" />
              <View style={styles.groupParent}>
                <Image
                  style={styles.bxtvIcon}
                  contentFit="cover"
                  source={require("../assets/bxtv.png")}
                />
                <Image
                  style={styles.majesticonstShirtLine}
                  contentFit="cover"
                  source={majesticonstShirtLine}
                />
              </View>
            </View>
          </View>
        </View>
      </View>
      <View style={[styles.frameParent3, styles.frameShadowBox]}>
        <View style={styles.frameContainer}>
          <View style={[styles.engVsAusParent, styles.wrapperParentFlexBox]}>
            <Text style={styles.engVsAus}>ENG vs IND</Text>
            <Image
              style={styles.bxbellPlusIcon}
              contentFit="cover"
              source={require("../assets/bxbellplus.png")}
            />
          </View>
          <View style={[styles.vectorWrapper, styles.wrapperParentFlexBox]}>
            <Image
              style={styles.frameChild}
              contentFit="cover"
              source={require("../assets/vector-3.png")}
            />
          </View>
        </View>
        <View style={styles.frameView}>
          <View style={styles.frameParent1}>
            <View style={[styles.englandParent, styles.wrapperParentFlexBox]}>
              <Text style={[styles.england, styles.englandTypo]}>England</Text>
              <Text style={[styles.australia, styles.englandTypo]}>INDIA</Text>
            </View>
            <View style={styles.frameParent2}>
              <View style={styles.groupParent}>
                <Image
                  style={styles.frameLayout}
                  contentFit="cover"
                  source={require("../assets/group-82.png")}
                />
                <Text style={[styles.eng, styles.engTypo]}>ENG</Text>
              </View>
              <Statustime statustimePosition="unset" h21mColor="#d54d4c" />
              <View style={styles.groupParent}>
                <Text style={styles.engTypo}>IND</Text>
                <Image
                  style={[styles.frameInner, styles.frameLayout]}
                  contentFit="cover"
                  source={require("../assets/group-83.png")}
                />
              </View>
            </View>
          </View>
          <View style={[styles.frameWrapper, styles.wrapperParentFlexBox]}>
            <View style={styles.teamOrMegaParent}>
              <Property1mega property1megaPosition="unset" />
              <View style={styles.groupParent}>
                <Image
                  style={styles.bxtvIcon}
                  contentFit="cover"
                  source={require("../assets/bxtv.png")}
                />
                <Image
                  style={styles.majesticonstShirtLine}
                  contentFit="cover"
                  source={majesticonstShirtLine1}
                />
              </View>
            </View>
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  frameShadowBox: {
    shadowOpacity: 1,
    elevation: 2,
    shadowRadius: 2,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.09)",
    backgroundColor: Color.colorWhite,
    borderRadius: Border.br_5xs,
    alignItems: "center",
    alignSelf: "stretch",
  },
  wrapperParentFlexBox: {
    paddingHorizontal: Padding.p_sm,
    alignItems: "center",
    alignSelf: "stretch",
  },
  englandTypo: {
    color: Color.black11,
    fontFamily: FontFamily.interRegular,
    fontSize: FontSize.size_xs,
  },
  engTypo: {
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
    color: Color.black11,
    textAlign: "left",
    fontSize: FontSize.size_xs,
  },
  frameLayout: {
    height: 24,
    width: 36,
  },
  engVsAus: {
    color: Color.black2,
    textAlign: "left",
    fontFamily: FontFamily.interRegular,
    fontSize: FontSize.size_xs,
  },
  bxbellPlusIcon: {
    width: 20,
    height: 20,
    overflow: "hidden",
  },
  engVsAusParent: {
    paddingTop: Padding.p_6xs,
    justifyContent: "space-between",
    flexDirection: "row",
  },
  frameChild: {
    maxWidth: "100%",
    maxHeight: "100%",
    width: "100%",
    overflow: "hidden",
    alignSelf: "stretch",
  },
  vectorWrapper: {
    height: 13,
    paddingVertical: Padding.p_3xs,
    justifyContent: "space-between",
  },
  frameContainer: {
    alignItems: "center",
    alignSelf: "stretch",
  },
  england: {
    textAlign: "left",
  },
  australia: {
    textAlign: "right",
  },
  englandParent: {
    paddingVertical: 0,
    justifyContent: "space-between",
    flexDirection: "row",
  },
  eng: {
    marginLeft: 6,
  },
  groupParent: {
    flexDirection: "row",
    alignItems: "center",
  },
  frameInner: {
    marginLeft: 6,
  },
  frameParent2: {
    justifyContent: "space-between",
    flexDirection: "row",
    alignItems: "center",
    alignSelf: "stretch",
    marginTop: 8,
  },
  frameParent1: {
    alignSelf: "stretch",
  },
  bxtvIcon: {
    width: 17,
    height: 17,
    overflow: "hidden",
  },
  majesticonstShirtLine: {
    width: 15,
    height: 15,
    marginLeft: 5,
    overflow: "hidden",
  },
  teamOrMegaParent: {
    justifyContent: "space-between",
    flexDirection: "row",
    alignItems: "center",
    alignSelf: "stretch",
  },
  frameWrapper: {
    borderBottomRightRadius: Border.br_5xs,
    borderBottomLeftRadius: Border.br_5xs,
    backgroundColor: Color.colorWhitesmoke,
    height: 31,
    paddingVertical: Padding.p_7xs,
    marginTop: 8,
  },
  frameView: {
    marginTop: 2,
    alignSelf: "stretch",
  },
  frameGroup: {
    alignItems: "center",
  },
  frameParent3: {
    marginTop: 3,
    alignItems: "center",
  },
  frameParent: {
    width: 336,
    marginTop: 8,
  },
});

export default Section;
