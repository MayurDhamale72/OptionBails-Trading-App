import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View, ImageSourcePropType } from "react-native";
import { Color, FontFamily, FontSize, Padding } from "../GlobalStyles";

const SectionWithBailsForm = ({ dimensionCode, productCode }) => {
  return (
    <View style={[styles.frameParent, styles.frameFlexBox]}>
      <View style={styles.groupParent}>
        <Image
          style={styles.frameLayout}
          contentFit="cover"
          source={require("../assets/group-58.png")}
        />
        <View style={styles.groupContainer}>
          <View style={[styles.bailsParent, styles.optionLayout]}>
            <Text style={[styles.bails, styles.bailsTypo]}> BAILS</Text>
            <Text style={[styles.option, styles.bailsTypo]}>OPTION</Text>
          </View>
          <Image
            style={styles.vectorIcon}
            contentFit="cover"
            source={require("../assets/vector1.png")}
          />
          <Image
            style={[styles.groupChild, styles.groupLayout]}
            contentFit="cover"
            source={dimensionCode}
          />
          <Image
            style={[styles.groupItem, styles.groupLayout]}
            contentFit="cover"
            source={productCode}
          />
        </View>
      </View>
      <View style={[styles.frameView, styles.frameFlexBox]}>
        <Image
          style={styles.frameLayout}
          contentFit="cover"
          source={require("../assets/group-57.png")}
        />
        <Image
          style={[styles.frameInner, styles.frameLayout]}
          contentFit="cover"
          source={require("../assets/group-56.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  frameFlexBox: {
    alignItems: "center",
    flexDirection: "row",
  },
  optionLayout: {
    width: 83,
    top: 0,
  },
  bailsTypo: {
    height: 27,
    textAlign: "center",
    color: Color.colorWhite,
    fontFamily: FontFamily.cambayBold,
    fontWeight: "700",
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  groupLayout: {
    height: 19,
    width: 16,
    position: "absolute",
  },
  frameLayout: {
    height: 40,
    width: 40,
  },
  bails: {
    top: 15,
    width: 63,
    left: 8,
  },
  option: {
    left: 0,
    width: 83,
    top: 0,
  },
  bailsParent: {
    left: 26,
    position: "absolute",
    height: 42,
  },
  vectorIcon: {
    top: 17,
    width: 20,
    height: 20,
    left: 8,
    position: "absolute",
  },
  groupChild: {
    top: 7,
    left: 0,
  },
  groupItem: {
    top: 1,
    left: 14,
  },
  groupContainer: {
    width: 109,
    marginLeft: 40,
    height: 42,
  },
  groupParent: {
    flex: 1,
    flexDirection: "row",
  },
  frameInner: {
    marginLeft: 10,
  },
  frameView: {
    width: 79,
    justifyContent: "flex-end",
    marginLeft: 4,
  },
  frameParent: {
    alignSelf: "stretch",
    backgroundColor: Color.colorRoyalblue,
    height: 78,
    justifyContent: "center",
    paddingHorizontal: Padding.p_xl,
    paddingTop: Padding.p_xl,
  },
});

export default SectionWithBailsForm;
