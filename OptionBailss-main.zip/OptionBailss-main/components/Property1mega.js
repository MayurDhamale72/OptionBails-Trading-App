import React, { useMemo } from "react";
import { Text, StyleSheet, View } from "react-native";
import { FontFamily, FontSize, Color } from "../GlobalStyles";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const Property1mega = ({ property1megaPosition }) => {
  const property1megaStyle = useMemo(() => {
    return {
      ...getStyleValue("position", property1megaPosition),
    };
  }, [property1megaPosition]);

  return (
    <View style={[styles.property1mega, property1megaStyle]}>
      <View style={styles.megaParentLayout}>
        <Text style={[styles.mega, styles.megaTypo]}>Mega</Text>
        <View style={[styles.groupChild, styles.megaParentLayout]} />
      </View>
      <View style={styles.rs6CroreWrapper}>
        <Text style={[styles.rs6Crore, styles.megaTypo]}>Rs 6 crore</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  megaTypo: {
    textAlign: "left",
    fontFamily: FontFamily.robotoBold,
    fontWeight: "700",
  },
  megaParentLayout: {
    height: 14,
    width: 34,
  },
  mega: {
    top: 1,
    left: 5,
    fontSize: FontSize.size_3xs,
    color: Color.green1,
    position: "absolute",
  },
  groupChild: {
    top: 0,
    left: 0,
    borderStyle: "solid",
    borderColor: Color.green1,
    borderWidth: 1,
    position: "absolute",
  },
  rs6Crore: {
    fontSize: FontSize.size_xs,
    color: Color.black1,
  },
  rs6CroreWrapper: {
    marginLeft: 5,
    flexDirection: "row",
  },
  property1mega: {
    alignItems: "center",
    flexDirection: "row",
  },
});

export default Property1mega;
