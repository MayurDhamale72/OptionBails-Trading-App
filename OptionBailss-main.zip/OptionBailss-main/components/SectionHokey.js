import React, { useMemo } from "react";
import { Image } from "expo-image";
import {
  StyleSheet,
  Text,
  View,
  Pressable,
  ImageSourcePropType,
} from "react-native";
import Property1off from "./Property1off";
import Property1off1 from "./Property1off1";
import Property1off2 from "./Property1off2";
import Property1off3 from "./Property1off3";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const SectionHokey = ({
  vector,
  group60,
  propColor,
  propBackgroundColor,
  propColor1,
  propBackgroundColor1,
  onCricketPress,
  onFootballPress,
  onBasketballPress,
  onBaseballPress,
}) => {
  const baseballStyle = useMemo(() => {
    return {
      ...getStyleValue("color", propColor),
    };
  }, [propColor]);

  const rectangleView4Style = useMemo(() => {
    return {
      ...getStyleValue("backgroundColor", propBackgroundColor),
    };
  }, [propBackgroundColor]);

  const hokey1Style = useMemo(() => {
    return {
      ...getStyleValue("color", propColor1),
    };
  }, [propColor1]);

  const rectangleView5Style = useMemo(() => {
    return {
      ...getStyleValue("backgroundColor", propBackgroundColor1),
    };
  }, [propBackgroundColor1]);

  return (
    <View style={styles.cricketParent}>
      <Property1off
        dimensionsCode={require("../assets/vector2.png")}
        property1offPosition="unset"
        onCricketPress={() => navigation.navigate("CricketHomePageExplore")}
      />
      <Property1off1
        dimensionCode={require("../assets/group-22.png")}
        property1offPosition="unset"
        property1offMarginLeft={35}
        onFootballPress={() => navigation.navigate("FootballHomePageExplore")}
      />
      <Property1off2
        locationCode={require("../assets/vector3.png")}
        property1offPosition="unset"
        property1offMarginLeft={35}
        onBasketballPress={() =>
          navigation.navigate("BasketballHomePageExplore")
        }
      />
      <Property1off3
        productCode={require("../assets/vector4.png")}
        property1offPosition="unset"
        property1offMarginLeft={35}
        onBaseballPress={() => navigation.navigate("BaseballHomePageExplore")}
      />
      <View style={styles.hokey}>
        <Image style={styles.hokeyChild} contentFit="cover" source={group60} />
        <Text style={[styles.hokey1, hokey1Style]}>Hokey</Text>
        <View style={[styles.hokeyItem, rectangleView5Style]} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  hokeyChild: {
    width: 20,
    height: 20,
  },
  hokey1: {
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.interRegular,
    color: Color.colorRoyalblue,
    textAlign: "center",
    marginTop: 3,
  },
  hokeyItem: {
    backgroundColor: Color.colorRoyalblue,
    width: 30,
    height: 3,
    marginTop: 3,
  },
  hokey: {
    marginLeft: 35,
    alignItems: "center",
  },
  cricketParent: {
    width: 336,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
  },
});

export default SectionHokey;
