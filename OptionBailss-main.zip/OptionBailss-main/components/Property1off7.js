import React, { useMemo } from "react";
import { Text, StyleSheet, View } from "react-native";
import { FontSize, FontFamily, Color, Border, Padding } from "../GlobalStyles";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const Property1off7 = ({ property1offPosition, onCompletedPress }) => {
  const property1off7Style = useMemo(() => {
    return {
      ...getStyleValue("position", property1offPosition),
    };
  }, [property1offPosition]);

  return (
    <View
      style={[styles.property1off, property1off7Style]}
      onPress={onCompletedPress}
    >
      <Text style={styles.completed}>Completed</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  completed: {
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.interRegular,
    color: Color.colorWhite,
    textAlign: "center",
  },
  property1off: {
    borderRadius: Border.br_9xs,
    backgroundColor: Color.colorDarkgray,
    height: 20,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    padding: Padding.p_3xs,
  },
});

export default Property1off7;
