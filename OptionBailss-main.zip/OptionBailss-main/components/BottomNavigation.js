import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View, Pressable } from "react-native";
import { TouchableOpacity } from "react-native-gesture-handler";
import Property1on1 from "./Property1on1";
import Property1off9 from "./Property1off9";
import Property1off10 from "./Property1off10";
import Property1off11 from "./Property1off11";
import Property1off12 from "./Property1off12";
import { Color, Padding } from "../GlobalStyles";
import { Button } from "@rneui/base";
import { useNavigation } from "@react-navigation/native";
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
const Tab = createBottomTabNavigator();
const BottomNavigation = () => {
  const navigation = useNavigation();

  const HandleButton = () =>{
   console.warn("sfsf");
  }
  return (
    <View style={styles.homeParent}>
      <TouchableOpacity onPress={() => navigation.navigate("MainHomeScreen")}>
        <Property1on1 
          group59={require("../assets/group-59.png")}
          property1onPosition="unset"
        />
    </TouchableOpacity>

      <TouchableOpacity onPress={() => navigation.navigate("CreateWatchlist")}>
        <Property1off9
          iconDocStarAlt={require("../assets/-icon-doc-star-alt.png")}
          property1offPosition="unset"
          property1offMarginLeft={25}
        />
      </TouchableOpacity>
    
      <TouchableOpacity onPress={() => navigation.navigate("Portfolio")}>
      <Property1off10
        wallet={require("../assets/wallet.png")}
        property1offPosition="unset"
        property1offMarginLeft={25}
        // onPortfolioPress={() => navigation.navigate("Portfolio")}
      />
      </TouchableOpacity>

      <TouchableOpacity onPress={() => navigation.navigate("Orders")}>
      <Property1off11
        dimensionsCode={require("../assets/-icon-notes.png")}
        property1offPosition="unset"
        property1offMarginLeft={25}
        // onOrdersPress={() => navigation.navigate("Orders")}
      />
      </TouchableOpacity>

      <TouchableOpacity onPress={() => navigation.navigate("Portfolio")}>
      <Property1off12
        iconProfileCircled={require("../assets/-icon-profile-circled.png")}
        property1offPosition="unset"
        property1offMarginLeft={25}
      />
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  homeParent: {
    alignSelf: "stretch",
    backgroundColor: Color.colorWhite,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 0,
    paddingVertical: Padding.p_mini,
  },
});

export default BottomNavigation;
