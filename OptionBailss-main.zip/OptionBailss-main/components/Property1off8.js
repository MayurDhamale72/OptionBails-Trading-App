import React, { useMemo } from "react";
import { Text, StyleSheet, View } from "react-native";
import { FontSize, FontFamily, Color, Border, Padding } from "../GlobalStyles";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const Property1off8 = ({
  prizeAmount,
  property1offPosition,
  winningsFontSize,
  winningsFontFamily,
  winningsColor,
  winningsTextAlign,
  onWinningsPress,
  onWinningsPress1,
}) => {
  const property1off8Style = useMemo(() => {
    return {
      ...getStyleValue("position", property1offPosition),
    };
  }, [property1offPosition]);

  const winningsStyle = useMemo(() => {
    return {
      ...getStyleValue("fontSize", winningsFontSize),
      ...getStyleValue("fontFamily", winningsFontFamily),
      ...getStyleValue("color", winningsColor),
      ...getStyleValue("textAlign", winningsTextAlign),
    };
  }, [winningsFontSize, winningsFontFamily, winningsColor, winningsTextAlign]);

  return (
    <View
      style={[styles.property1off, property1off8Style]}
      onPress={onWinningsPress}
    >
      <Text style={[styles.winnings, winningsStyle]} onPress={onWinningsPress1}>
        {prizeAmount}
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  winnings: {
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.interRegular,
    color: Color.colorWhite,
    textAlign: "center",
  },
  property1off: {
    borderRadius: Border.br_9xs,
    backgroundColor: Color.colorDarkgray,
    height: 20,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    padding: Padding.p_3xs,
  },
});

export default Property1off8;
