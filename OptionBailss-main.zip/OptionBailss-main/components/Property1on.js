import React, { useMemo } from "react";
import { Text, StyleSheet, View } from "react-native";
import { FontSize, FontFamily, Color, Border, Padding } from "../GlobalStyles";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const Property1on = ({ property1onPosition }) => {
  const property1onStyle = useMemo(() => {
    return {
      ...getStyleValue("position", property1onPosition),
    };
  }, [property1onPosition]);

  return (
    <View style={[styles.property1on, property1onStyle]}>
      <Text style={styles.explore}>Explore</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  explore: {
    flex: 1,
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.interRegular,
    color: Color.colorWhite,
    textAlign: "center",
  },
  property1on: {
    borderRadius: Border.br_9xs,
    backgroundColor: Color.colorRoyalblue,
    width: 56,
    height: 20,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    padding: Padding.p_3xs,
  },
});

export default Property1on;
