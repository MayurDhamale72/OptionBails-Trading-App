import React, { useMemo } from "react";
import { StyleSheet, View, Text } from "react-native";
import { Border, Color, FontSize, FontFamily } from "../GlobalStyles";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const GroupComponent = ({
  carNumber,
  groupViewAlignSelf,
  groupViewFlex,
  groupViewMarginLeft,
}) => {
  const groupViewStyle = useMemo(() => {
    return {
      ...getStyleValue("alignSelf", groupViewAlignSelf),
      ...getStyleValue("flex", groupViewFlex),
      ...getStyleValue("marginLeft", groupViewMarginLeft),
    };
  }, [groupViewAlignSelf, groupViewFlex, groupViewMarginLeft]);

  return (
    <View style={[styles.rectangleParent, groupViewStyle]}>
      <View style={styles.componentChild} />
      <Text style={styles.text}>{carNumber}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  componentChild: {
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    borderRadius: Border.br_9xs,
    backgroundColor: Color.colorWhite,
    borderStyle: "solid",
    borderColor: Color.colorRoyalblue,
    borderWidth: 1.5,
    position: "absolute",
  },
  text: {
    top: "30%",
    left: "40%",
    fontSize: FontSize.size_sm,
    fontWeight: "600",
    fontFamily: FontFamily.interSemiBold,
    color: Color.colorRoyalblue,
    textAlign: "center",
    position: "absolute",
  },
  rectangleParent: {
    alignSelf: "stretch",
    flex: 1,
  },
});

export default GroupComponent;
