import React, { useMemo } from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View, ImageSourcePropType } from "react-native";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const Property1off1 = ({
  dimensionCode,
  property1offPosition,
  property1offMarginLeft,
  onFootballPress,
}) => {
  const property1off1Style = useMemo(() => {
    return {
      ...getStyleValue("position", property1offPosition),
      ...getStyleValue("marginLeft", property1offMarginLeft),
    };
  }, [property1offPosition, property1offMarginLeft]);

  return (
    <View
      style={[styles.property1off, property1off1Style]}
      onPress={onFootballPress}
    >
      <Image
        style={styles.property1offChild}
        contentFit="cover"
        source={dimensionCode}
      />
      <Text style={styles.football}>Football</Text>
      <View style={styles.property1offItem} />
    </View>
  );
};

const styles = StyleSheet.create({
  property1offChild: {
    width: 20,
    height: 20,
  },
  football: {
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.interRegular,
    color: Color.colorDarkgray,
    textAlign: "center",
    marginTop: 3,
  },
  property1offItem: {
    backgroundColor: Color.colorDarkgray_100,
    width: 38,
    height: 3,
    marginTop: 3,
  },
  property1off: {
    alignItems: "center",
  },
});

export default Property1off1;
