import React, { useMemo } from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View, ImageSourcePropType } from "react-native";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const Property1off11 = ({
  dimensionsCode,
  property1offPosition,
  property1offMarginLeft,
  onOrdersPress,
}) => {
  const property1off11Style = useMemo(() => {
    return {
      ...getStyleValue("position", property1offPosition),
      ...getStyleValue("marginLeft", property1offMarginLeft),
    };
  }, [property1offPosition, property1offMarginLeft]);

  return (
    <View
      style={[styles.property1off, property1off11Style]}
      onPress={onOrdersPress}
    >
      <Image
        style={styles.iconNotes}
        contentFit="cover"
        source={dimensionsCode}
      />
      <Text style={styles.orders}>ORDERS</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  iconNotes: {
    width: 14,
    height: 18,
  },
  orders: {
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.interRegular,
    color: Color.colorDarkgray,
    textAlign: "center",
    marginTop: 5,
  },
  property1off: {
    alignItems: "center",
  },
});

export default Property1off11;
