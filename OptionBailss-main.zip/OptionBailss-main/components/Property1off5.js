import React, { useMemo } from "react";
import { Text, StyleSheet, View } from "react-native";
import { FontSize, FontFamily, Color, Border, Padding } from "../GlobalStyles";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const Property1off5 = ({ property1offPosition, onLivePress }) => {
  const property1off5Style = useMemo(() => {
    return {
      ...getStyleValue("position", property1offPosition),
    };
  }, [property1offPosition]);

  return (
    <View
      style={[styles.property1off, property1off5Style]}
      onPress={onLivePress}
    >
      <Text style={styles.live}>Live</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  live: {
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.interRegular,
    color: Color.colorWhite,
    textAlign: "center",
  },
  property1off: {
    borderRadius: Border.br_9xs,
    backgroundColor: Color.colorDarkgray,
    height: 20,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    padding: Padding.p_3xs,
  },
});

export default Property1off5;
