import React, { useMemo } from "react";
import { Text, StyleSheet, View } from "react-native";
import { FontSize, FontFamily, Color, Border, Padding } from "../GlobalStyles";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const Property1off6 = ({ property1offPosition, onUpcomingPress }) => {
  const property1off6Style = useMemo(() => {
    return {
      ...getStyleValue("position", property1offPosition),
    };
  }, [property1offPosition]);

  return (
    <View
      style={[styles.property1off, property1off6Style]}
      onPress={onUpcomingPress}
    >
      <Text style={styles.upcoming}>Upcoming</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  upcoming: {
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.interRegular,
    color: Color.colorWhite,
    textAlign: "center",
  },
  property1off: {
    borderRadius: Border.br_9xs,
    backgroundColor: Color.colorDarkgray,
    height: 20,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    padding: Padding.p_3xs,
  },
});

export default Property1off6;
