// Import the necessary components
import React, { useState } from "react";
import { Text, StyleSheet, View, TouchableOpacity, Image, Alert } from "react-native";
import { Button, Input } from "@rneui/themed";
import { FontSize, FontFamily, Border, Color } from "../GlobalStyles";
import OTPVerification from "./OTPVerification";
import Otpver from "./Otpver";

import PhoneInput from "react-native-phone-number-input";
// Define SignUp component
const SignUp = ({ navigation }) => {
    return (
        <View style={styles.signUp1}>
            <View style={styles.frameParent}>
                <View style={styles.letsGetStartedParent}>
                    <Text style={styles.letsGetStarted}>Lets Get Started</Text>
                    <Text style={[styles.letsTradeThe, styles.letsTradeTheTypo]}>
                        Let’s Trade the Game!
                    </Text>
                </View>

                {/* phone number text box */}
                {/* <View style={styles.input1Parent}>
                    <View style={styles.input1Position}>
                        <View style={[styles.input1Child, styles.input1Position]} />
                    </View>
                    <Input
                        placeholder="Phone Number"
                        inputStyle={{ color: "#aab2bd" }}
                        containerStyle={styles.signUpEmailInput}
                    />
                    <Image
                        style={[styles.iconEnvelope, styles.iconPosition]}
                        contentFit="cover"
                        source={require("../assets/-icon-envelope.png")}
                    />
                </View> */}
                
                < Number />
                
                {/* Get Otp Button */}
                <OTPverr navigation={navigation} />

                {/* extra text */}
                <Text style={[styles.alreadyHaveAnContainer, styles.letsTradeTheTypo]}>
                    <Text style={styles.alreadyHaveAn}>Already Have an Account? </Text>
                    <Text style={styles.signIn}>Sign In</Text>
                </Text>
            </View>
        </View>
    );
};

const Number = () => {
    const [phoneNumber, setPhoneNumber] = useState('');

    const getPhoneNumber = () => {
        Alert.alert('Phone Number', phoneNumber);
    };

    return (
        <View style={styles.input1Parent}>

            {/* this for style */}
            <View style={styles.input1Position}>
                        <View style={[styles.input1Child, styles.input1Position]} />
            </View>
            <PhoneInput
                defaultValue={phoneNumber}
                defaultCode="IN"
                layout="first"
                withShadow
                autoFocus
                style={styles.phoneInput} 
                onChangeFormattedText={text => { setPhoneNumber(text); }}
                value="9604222607"
            />
            {/* <Button title="Get Phone Number" onPress={getPhoneNumber} /> */}
        </View>
    );
};


// Define OTPver component
const OTPverr = ({ navigation }) => {
    return (
        <View style={styles.button}>
            {/* <Button title="ver" onPress={() => navigation.navigate('OTPVerification')} /> */}
            <TouchableOpacity onPress={() => navigation.navigate('Otpver')}>
                <Text style={[styles.signWithmob]}>
                    Get OTP
                </Text>
            </TouchableOpacity>
        </View>
    );
};

// const OTPver = ({ navigation }) => {
//     return (
//         <View style={styles.button}>
//             {/* <Button title="ver" onPress={() => navigation.navigate('OTPVerification')} /> */}
//             <TouchableOpacity onPress={() => navigation.navigate('OTPVerification')}>
//                 <Text style={[styles.signWithmob]}>
//                     Get OTP
//                 </Text>
//             </TouchableOpacity>
//         </View>
//     );
// };

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff',
    },
    phoneInput: {
        width: '80%', // Adjust width as needed
        height: 50, // Adjust height as needed
        marginBottom: 20,
        borderWidth: 1,
        borderColor: '#ccc',
        borderRadius: 5,
        paddingHorizontal: 10,
    },
    button: {
        height: 65,
        width: 300,
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "blue",
        borderRadius: 20,
        marginVertical: 20,
    },
    signWithmob: {
        fontWeight: "600",
        fontSize: 18,
        fontWeight: "bold",
    },
    signUpEmailInput: {
        left: "50%",
        marginLeft: -84,
        marginTop: -12,
        top: "50%",
        position: "absolute",
    },
    letsTradeTheTypo: {
        fontSize: FontSize.size_sm,
        textAlign: "center",
        fontFamily: FontFamily.interSemiBold,
        fontWeight: "600",
    },
    input1Position: {
        borderRadius: Border.br_9xs,
        left: "50%",
        top: "50%",
        marginLeft: -150,
        marginTop: -29,
        height: 58,
        width: 300,
        position: "absolute",
    },
    iconPosition: {
        left: "50%",
        top: "50%",
        position: "absolute",
    },
    signPosition: {
        fontSize: FontSize.size_lg,
        marginTop: -12,
        left: "50%",
        top: "50%",
        textAlign: "center",
        color: Color.colorBlack,
        position: "absolute",
    },
    letsGetStarted: {
        fontSize: 25,
        textAlign: "center",
        color: Color.colorBlack,
        fontFamily: FontFamily.interSemiBold,
        fontWeight: "600",
    },
    letsTradeThe: {
        marginTop: 32,
        color: Color.colorDarkgray,
    },
    letsGetStartedParent: {
        alignItems: "center",
    },
    input1Child: {
        backgroundColor: "#fff",
    },
    iconEnvelope: {
        marginTop: -9,
        marginLeft: -131,
        width: 25,
        height: 19,
    },
    input1Parent: {
        marginTop: 33,
        height: 58,
        width: 300,
    },
    orUseInstatnt: {
        marginTop: 33,
        color: Color.colorDarkgray,
    },
    input2Child: {
        borderRadius: Border.br_xs,
        borderStyle: "solid",
        borderColor: Color.colorDarkgray,
        borderWidth: 1.5,
        marginLeft: -150,
        marginTop: -29,
        top: "50%",
        height: 58,
        width: 300,
    },

    download3RemovebgPreviewIcon: {
        marginTop: -15,
        marginLeft: -136,
        width: 30,
        height: 30,
    },

    alreadyHaveAn: {
        color: Color.colorDarkgray,
    },
    signIn: {
        color: "#0866ff",
    },
    alreadyHaveAnContainer: {
        marginTop: 33,
    },
    frameParent: {
        top: 174,
        left: 30,
        justifyContent: "center",
        alignItems: "center",
        position: "absolute",
    },
    signUp1: {
        backgroundColor: "#f5f6fb",
        flex: 1,
        width: "100%",
        height: 800,
        overflow: "hidden",
    },
});

export default SignUp;
