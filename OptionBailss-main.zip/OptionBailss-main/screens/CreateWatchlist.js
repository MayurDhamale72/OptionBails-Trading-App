import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import SectionWithBailsForm from "../components/SectionWithBailsForm";
import Property1off10 from "../components/Property1off10";
import Property1off11 from "../components/Property1off11";
import Property1off12 from "../components/Property1off12";
import { FontFamily, FontSize, Color, Border, Padding } from "../GlobalStyles";
import BottomNavigation from "../components/BottomNavigation";
const CreateWatchlist = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.createWatchlist}>
      <SectionWithBailsForm
        dimensionCode={require("../assets/group-732.png")}
        productCode={require("../assets/group-741.png")}
      />
      <View style={styles.listInfoFlexBox}>
        <View style={styles.listInfoInnerLayout}>
          <View style={styles.input1Position}>
            <View style={[styles.input1, styles.input1Position]}>
              <View style={[styles.input1Child, styles.largeChildPosition]} />
            </View>
            <View style={styles.listNameParent}>
              <Text style={[styles.listName, styles.textTypo]}>List Name</Text>
              <Text style={[styles.text, styles.textTypo]}>03/15</Text>
            </View>
          </View>
        </View>
        <View style={[styles.largeBtnParent, styles.listInfoInnerLayout]}>
          <View style={[styles.largeBtn, styles.largeChildPosition]}>
            <View style={[styles.largeBtnChild, styles.largeChildPosition]} />
          </View>
          <Text style={[styles.create, styles.largeChildPosition]}>CREATE</Text>
        </View>
      </View>
      <View style={[styles.homeParent, styles.listInfoFlexBox]}>
        <View style={styles.home}>
          <Image
            style={styles.homeChild}
            contentFit="cover"
            source={require("../assets/group-592.png")}
          />
          <Text style={[styles.home1, styles.home1Typo]}>HOME</Text>
        </View>
        <View style={styles.watchlist}>
          <Image
            style={styles.iconDocStarAlt}
            contentFit="cover"
            source={require("../assets/-icon-doc-star-alt3.png")}
          />
          <Text style={[styles.watchlist1, styles.home1Typo]}>WATCHLIST</Text>
        </View>
        <Property1off10
          wallet={require("../assets/wallet.png")}
          property1offPosition="unset"
          property1offMarginLeft={25}
          onPortfolioPress={() => navigation.navigate("Portfolio")}
        />
        <Property1off11
          dimensionsCode={require("../assets/-icon-notes.png")}
          property1offPosition="unset"
          property1offMarginLeft={25}
          onOrdersPress={() => navigation.navigate("Orders")}
        />
        <Property1off12
          iconProfileCircled={require("../assets/-icon-profile-circled.png")}
          property1offPosition="unset"
          property1offMarginLeft={25}
        />
      </View>
      <BottomNavigation />
    </View>
  );
};

const styles = StyleSheet.create({
  input1Position: {
    left: 0,
    top: 0,
    position: "absolute",
    height: 58,
    width: 300,
  },
  largeChildPosition: {
    left: "50%",
    top: "50%",
    position: "absolute",
  },
  textTypo: {
    fontFamily: FontFamily.interSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_lg,
    textAlign: "center",
    color: Color.colorDarkgray,
  },
  listInfoInnerLayout: {
    height: 58,
    width: 300,
  },
  listInfoFlexBox: {
    justifyContent: "center",
    alignSelf: "stretch",
    alignItems: "center",
  },
  home1Typo: {
    marginTop: 5,
    fontFamily: FontFamily.interRegular,
    fontSize: FontSize.size_3xs,
    textAlign: "center",
  },
  input1Child: {
    backgroundColor: Color.colorWhite,
    marginLeft: -150,
    marginTop: -29,
    top: "50%",
    height: 58,
    width: 300,
    borderRadius: Border.br_9xs,
  },
  input1: {
    borderRadius: Border.br_9xs,
  },
  listName: {
    textAlign: "center",
    color: Color.colorDarkgray,
  },
  text: {
    marginLeft: 125,
    textAlign: "center",
    color: Color.colorDarkgray,
  },
  listNameParent: {
    top: 18,
    left: 15,
    flexDirection: "row",
    position: "absolute",
  },
  largeBtnChild: {
    backgroundColor: Color.colorRoyalblue,
    marginLeft: -150,
    marginTop: -29,
    top: "50%",
    height: 58,
    width: 300,
    borderRadius: Border.br_9xs,
  },
  largeBtn: {
    marginLeft: -150,
    marginTop: -29,
    top: "50%",
    height: 58,
    width: 300,
  },
  create: {
    marginTop: -7,
    marginLeft: -28,
    fontSize: FontSize.size_sm,
    fontWeight: "700",
    fontFamily: FontFamily.interBold,
    color: Color.colorWhite,
    textAlign: "center",
  },
  largeBtnParent: {
    marginTop: 35,
  },
  homeChild: {
    width: 20,
    height: 18,
  },
  home1: {
    color: Color.colorDarkgray,
  },
  home: {
    alignItems: "center",
  },
  iconDocStarAlt: {
    width: 15,
    height: 18,
  },
  watchlist1: {
    color: Color.colorRoyalblue,
  },
  watchlist: {
    marginLeft: 25,
    alignItems: "center",
  },
  homeParent: {
    paddingHorizontal: 0,
    paddingVertical: Padding.p_mini,
    flexDirection: "row",
    backgroundColor: Color.colorWhite,
  },
  createWatchlist: {
    backgroundColor: Color.colorGhostwhite,
    flex: 1,
    width: "100%",
    height: 800,
    justifyContent: "space-between",
    alignItems: "center",
  },
});

export default CreateWatchlist;
