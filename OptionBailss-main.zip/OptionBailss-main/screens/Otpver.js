import React, { useEffect, useRef, useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, Alert } from 'react-native';
import HomePageExplore from './MainHomeScreen';

const Otpver = ({navigation}) => {
  const et1 = useRef();
  const et2 = useRef();
  const et3 = useRef();
  const et4 = useRef();
  const [F1, setF1] = useState("");
  const [F2, setF2] = useState("");
  const [F3, setF3] = useState("");
  const [F4, setF4] = useState("");
  const [count, setCount] = useState(30);

  useEffect(() => {
    const interval = setInterval(() => {
      if (count === 0) {
        clearInterval(interval);
      } else {
        setCount(count - 1);
      }
    }, 1000);
    return () => {
      clearInterval(interval);
    };
  }, [count]);

  const clearFields = () => {
    setF1("");
    setF2("");
    setF3("");
    setF4("");
    et1.current.focus();
  };

  const otpValidate = () => {
    let otp = '1234';
    let enterotp = F1 + F2 + F3 + F4;
    if (enterotp === otp) {
      // Alert.alert('OTP Matched');
      navigation.navigate('MainHomeScreen');
    } else {
      Alert.alert('Wrong OTP');
      clearFields();
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Verify Code</Text>
      <Text style={styles.confirmation}>The confirmation code send via phone</Text>
      <View style={styles.otpView}>
        <TextInput
          ref={et1}
          style={[styles.inputView, { borderColor: F1.length >= 1 ? 'blue' : '#000' }]}
          placeholder='1'
          
          keyboardType='number-pad'
          maxLength={1}
          value={F1}
          onChangeText={txt => {
            setF1(txt);
            if (txt.length >= 1) {
              et2.current.focus();
            }
          }}
        />
        <TextInput
          ref={et2}
          style={[styles.inputView, { borderColor: F2.length >= 1 ? 'blue' : '#000' }]}
          placeholder='2'
          keyboardType='number-pad'
          maxLength={1}
          value={F2}
          onChangeText={txt => {
            setF2(txt);
            if (txt.length >= 1) {
              et3.current.focus();
            } else if (txt.length < 1) {
              et1.current.focus();
            }
          }}
        />
        <TextInput
          ref={et3}
          style={[styles.inputView, { borderColor: F3.length >= 1 ? 'blue' : '#000' }]}
          keyboardType='number-pad'
          placeholder='3'
          maxLength={1}
          value={F3}
          onChangeText={txt => {
            setF3(txt);
            if (txt.length >= 1) {
              et4.current.focus();
            } else if (txt.length < 1) {
              et2.current.focus();
            }
          }}
        />
        <TextInput
          ref={et4}
          style={[styles.inputView, { borderColor: F4.length >= 1 ? 'blue' : '#000' }]}
          placeholder='4'
          keyboardType='number-pad'
          maxLength={1}
          value={F4}
          onChangeText={txt => {
            setF4(txt);
            if (txt.length >= 1) {
              // You can add logic here if you want to automatically submit the OTP after the fourth digit
            } else if (txt.length < 1) {
              et3.current.focus();
            }
          }}
        />
      </View>
      <View style={styles.timerContainer}>
        {count !== 0 ? (
          <Text style={styles.timerText}>00:{count}s</Text>
        ) : (
          <TouchableOpacity onPress={() => setCount(30)}>
            <Text style={styles.resendText}>Resend OTP</Text>
          </TouchableOpacity>
        )}
      </View>
      {/* Resend Section */}
      <TouchableOpacity
        disabled={
          F1 !== '' &&
          F2 !== '' &&
          F3 !== '' &&
          F4 !== ''
            ? false
            : true
        }
        style={[
          styles.submitotpbtn,
          {
            backgroundColor:
              F1 !== '' &&
              F2 !== '' &&
              F3 !== '' &&
              F4 !== ''
                ? 'blue'
                : '#949494',
          },
        ]}
        onPress={otpValidate}>
        <Text style={styles.BtnTxt}>Submit</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  title: {
    fontSize: 22,
    fontWeight: '700',
    marginTop: 150,
    textAlign: 'center',
    color: '#000',
  },
  confirmation:{
    textAlign:'center',
    color:'gray',
    padding:10,
    marginLeft:80,
    marginRight:80,
    marginTop:40,
    marginBottom:40
  },
  otpView: {
    width: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
    marginTop: 20,
  },
  inputView: {
    width: 60,
    height: 60,
    borderWidth: 1.5,
    borderRadius: 5,
    marginLeft: 10,
    textAlign: 'center',
    fontSize: 18,
    fontWeight: '700',
  },
  submitotpbtn: {
    width: '80%',
    height: 55,
    backgroundColor: 'blue',
    borderRadius: 20,
    alignSelf: 'center',
    marginTop: 50,
    justifyContent: 'center',
    alignItems: 'center',
  },
  BtnTxt: {
    color: '#fff',
    fontSize: 20,
  },
  timerContainer: {
    alignItems: 'center',
    marginTop: 20,
  },
  timerText: {
    fontSize: 18,
    color: 'gray',
  },
  resendText: {
    fontSize: 18,
    color: 'blue',
    textDecorationLine: 'underline',
  },
});

export default Otpver;