import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import SectionWithBailsForm from "../components/SectionWithBailsForm";
import Property1off1 from "../components/Property1off1";
import Property1off2 from "../components/Property1off2";
import Property1off3 from "../components/Property1off3";
import Property1off4 from "../components/Property1off4";
import SectionWithNumbers from "../components/SectionWithNumbers";
import SectionRealisedGainForm from "../components/SectionRealisedGainForm";
import Property1on from "../components/Property1on";
import Property1off5 from "../components/Property1off5";
import Property1off6 from "../components/Property1off6";
import Property1off7 from "../components/Property1off7";
import Property1off8 from "../components/Property1off8";
import Section from "../components/Section";
import Section2 from "../components/Section2";
import { FontSize, FontFamily, Color, Border, Padding } from "../GlobalStyles";

const CricketHomePageExplore = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.cricketHomePageExplore}>
      <SectionWithBailsForm
        dimensionCode={require("../assets/group-731.png")}
        productCode={require("../assets/group-741.png")}
      />
      <View style={styles.frameParent}>
        <View style={[styles.cricketParent, styles.parentFlexBox]}>
          <View style={styles.cricket}>
            <Image
              style={styles.iconLayout}
              contentFit="cover"
              source={require("../assets/vector10.png")}
            />
            <Text style={styles.cricket1}>Cricket</Text>
            <View style={styles.cricketChild} />
          </View>
          <Property1off1
            dimensionCode={require("../assets/group-2.png")}
            property1offPosition="unset"
            property1offMarginLeft={35}
            onFootballPress={() =>
              navigation.navigate("FootballHomePageExplore")
            }
          />
          <Property1off2
            locationCode={require("../assets/vector3.png")}
            property1offPosition="unset"
            property1offMarginLeft={35}
            onBasketballPress={() =>
              navigation.navigate("BasketballHomePageExplore")
            }
          />
          <Property1off3
            productCode={require("../assets/vector4.png")}
            property1offPosition="unset"
            property1offMarginLeft={35}
            onBaseballPress={() =>
              navigation.navigate("BaseballHomePageExplore")
            }
          />
          <Property1off4
            group60={require("../assets/group-60.png")}
            property1offPosition="unset"
            property1offMarginLeft={35}
            onHokeyPress={() => navigation.navigate("HokeyHomePageExplore")}
          />
        </View>
        <Image
          style={styles.maskGroup11}
          contentFit="cover"
          source={require("../assets/mask-group-1-1.png")}
        />
        <View style={[styles.ellipseParent, styles.parentFlexBox]}>
          <Image
            style={styles.frameLayout}
            contentFit="cover"
            source={require("../assets/ellipse-54.png")}
          />
          <Image
            style={[styles.frameItem, styles.frameLayout]}
            contentFit="cover"
            source={require("../assets/ellipse-55.png")}
          />
          <Image
            style={[styles.frameItem, styles.frameLayout]}
            contentFit="cover"
            source={require("../assets/ellipse-55.png")}
          />
        </View>
        <SectionWithNumbers
          uniqueIdentifier={require("../assets/group-68.png")}
          uniqueIdentifierText={require("../assets/group-68.png")}
          dimensionText={require("../assets/group-687.png")}
        />
        <SectionRealisedGainForm />
        <View style={styles.exploreParent}>
          <Property1on property1onPosition="unset" />
          <Property1off5
            property1offPosition="unset"
            onLivePress={() => navigation.navigate("CricketHomePageLive")}
          />
          <Property1off6
            property1offPosition="unset"
            onUpcomingPress={() =>
              navigation.navigate("CricketHomePageUpcoming")
            }
          />
          <Property1off7
            property1offPosition="unset"
            onCompletedPress={() =>
              navigation.navigate("CricketHomePageCompleted")
            }
          />
          <Property1off8
            prizeAmount="Winnings"
            property1offPosition="unset"
            winningsFontSize={10}
            winningsFontFamily="Inter-Regular"
            winningsColor="#fff"
            winningsTextAlign="center"
            onWinningsPress={() =>
              navigation.navigate("CricketHomePageWinnings")
            }
          />
        </View>
        <View style={[styles.exploreHereParent, styles.parentFlexBox]}>
          <Text style={styles.exploreHere}>Explore Here</Text>
          <Image
            style={[styles.groupIcon, styles.iconLayout]}
            contentFit="cover"
            source={require("../assets/group-584.png")}
          />
        </View>
        <Section
          group81={require("../assets/group-82.png")}
          majesticonstShirtLine={require("../assets/majesticonstshirtline2.png")}
          majesticonstShirtLine1={require("../assets/majesticonstshirtline2.png")}
        />
      </View>
      <Section2
        group59={require("../assets/group-59.png")}
        iconDocStarAlt={require("../assets/-icon-doc-star-alt.png")}
        wallet={require("../assets/wallet.png")}
        iconNotes={require("../assets/-icon-notes.png")}
        iconProfileCircled={require("../assets/-icon-profile-circled.png")}
        propColor="#3f5bd9"
        propColor1="#aab2bd"
      />
    </View>
  );
};

const styles = StyleSheet.create({
  parentFlexBox: {
    justifyContent: "center",
    flexDirection: "row",
    alignItems: "center",
  },
  frameLayout: {
    height: 6,
    width: 6,
  },
  iconLayout: {
    height: 20,
    width: 20,
  },
  cricket1: {
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.interRegular,
    color: Color.colorRoyalblue,
    textAlign: "center",
    marginTop: 3,
  },
  cricketChild: {
    backgroundColor: Color.colorRoyalblue,
    width: 34,
    height: 3,
    marginTop: 3,
  },
  cricket: {
    alignItems: "center",
  },
  cricketParent: {
    width: 336,
  },
  maskGroup11: {
    borderRadius: Border.br_3xs,
    height: 67,
    marginTop: 8,
    width: 336,
  },
  frameItem: {
    marginLeft: 6,
  },
  ellipseParent: {
    marginTop: 8,
    width: 336,
  },
  exploreParent: {
    alignSelf: "stretch",
    marginTop: 8,
    flexDirection: "row",
    justifyContent: "space-between",
  },
  exploreHere: {
    fontSize: FontSize.size_sm,
    fontWeight: "600",
    fontFamily: FontFamily.interSemiBold,
    color: Color.colorBlack,
    textAlign: "left",
    flex: 1,
  },
  groupIcon: {
    marginLeft: 10,
  },
  exploreHereParent: {
    width: 337,
    height: 22,
    padding: Padding.p_3xs,
    marginTop: 8,
  },
  frameParent: {
    paddingHorizontal: 0,
    paddingVertical: Padding.p_5xs,
    alignItems: "center",
    flex: 1,
  },
  cricketHomePageExplore: {
    backgroundColor: Color.colorGhostwhite,
    width: "100%",
    height: 800,
    justifyContent: "space-between",
    alignItems: "center",
    flex: 1,
  },
});

export default CricketHomePageExplore;
