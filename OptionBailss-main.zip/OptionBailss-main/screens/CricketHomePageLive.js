import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import SectionWithBailsForm from "../components/SectionWithBailsForm";
import Section1 from "../components/Section1";
import SectionWithNumbers from "../components/SectionWithNumbers";
import SectionRealisedGainForm from "../components/SectionRealisedGainForm";
import Property1off6 from "../components/Property1off6";
import Property1off7 from "../components/Property1off7";
import Property1off8 from "../components/Property1off8";
import MatchupSection from "../components/MatchupSection";
import Section2 from "../components/Section2";
import { Padding, FontFamily, Border, Color, FontSize } from "../GlobalStyles";

const CricketHomePageLive = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.cricketHomePageLive}>
      <SectionWithBailsForm
        dimensionCode={require("../assets/group-731.png")}
        productCode={require("../assets/group-741.png")}
      />
      <View style={styles.frameParent}>
        <Section1
          dimensionCode={require("../assets/vector10.png")}
          dimensionCodeText={require("../assets/group-2.png")}
          dimensionCodeId={require("../assets/vector3.png")}
          dimensionCodeValue={require("../assets/group-60.png")}
          groupIconColor="#3f5bd9"
          hokeyBackgroundColor="#3f5bd9"
          propColor="#aab2bd"
          propBackgroundColor="rgba(170, 178, 189, 0)"
          propColor1="#aab2bd"
          propBackgroundColor1="rgba(170, 178, 189, 0)"
          propColor2="#aab2bd"
          propBackgroundColor2="rgba(170, 178, 189, 0)"
          onCricketPress={() => navigation.navigate("CricketHomePageExplore")}
          onFootballPress={() => navigation.navigate("FootballHomePageExplore")}
          onBasketballPress={() =>
            navigation.navigate("BasketballHomePageExplore")
          }
          onBaseballPress={() => navigation.navigate("BaseballHomePageExplore")}
          onHokeyPress={() => navigation.navigate("HokeyHomePageExplore")}
        />
        <Image
          style={styles.maskGroup11}
          contentFit="cover"
          source={require("../assets/mask-group-1-1.png")}
        />
        <View style={styles.ellipseParent}>
          <Image
            style={styles.frameLayout}
            contentFit="cover"
            source={require("../assets/ellipse-54.png")}
          />
          <Image
            style={[styles.frameItem, styles.frameLayout]}
            contentFit="cover"
            source={require("../assets/ellipse-55.png")}
          />
          <Image
            style={[styles.frameItem, styles.frameLayout]}
            contentFit="cover"
            source={require("../assets/ellipse-55.png")}
          />
        </View>
        <SectionWithNumbers
          uniqueIdentifier={require("../assets/group-68.png")}
          uniqueIdentifierText={require("../assets/group-68.png")}
          dimensionText={require("../assets/group-687.png")}
        />
        <SectionRealisedGainForm />
        <View style={styles.exploreParent}>
          <Pressable
            style={[styles.explore, styles.liveFlexBox]}
            onPress={() => navigation.navigate("CricketHomePageExplore")}
          >
            <Text style={[styles.explore1, styles.live1Typo]}>Explore</Text>
          </Pressable>
          <View style={[styles.live, styles.liveFlexBox]}>
            <Text style={[styles.live1, styles.live1Typo]}>Live</Text>
          </View>
          <Property1off6
            property1offPosition="unset"
            onUpcomingPress={() =>
              navigation.navigate("CricketHomePageUpcoming")
            }
          />
          <Property1off7
            property1offPosition="unset"
            onCompletedPress={() =>
              navigation.navigate("CricketHomePageCompleted")
            }
          />
          <Property1off8
            prizeAmount="Winnings"
            property1offPosition="unset"
            winningsFontSize={10}
            winningsFontFamily="Inter-Regular"
            winningsColor="#fff"
            winningsTextAlign="center"
            onWinningsPress={() =>
              navigation.navigate("CricketHomePageWinnings")
            }
          />
        </View>
        <View style={[styles.liveGamesParent, styles.liveFlexBox]}>
          <Text style={styles.liveGames}>Live Games</Text>
          <View style={styles.viewMore}>
            <Text style={[styles.viewMore1, styles.live1Typo]}>VIEW MORE</Text>
            <Image
              style={styles.viewMoreChild}
              contentFit="cover"
              source={require("../assets/group-673.png")}
            />
          </View>
        </View>
        <MatchupSection
          eNG="ENG"
          iNDVsENG="IND Vs ENG"
          group68={require("../assets/group-685.png")}
          iND="IND"
          majesticonstShirtLine={require("../assets/majesticonstshirtline2.png")}
          propAlignSelf="stretch"
        />
        <MatchupSection
          eNG="PAK"
          iNDVsENG="PAK Vs SA"
          group68={require("../assets/group-68.png")}
          iND="SA"
          majesticonstShirtLine={require("../assets/majesticonstshirtline2.png")}
          propAlignSelf="stretch"
        />
      </View>
      <Section2
        group59={require("../assets/group-59.png")}
        iconDocStarAlt={require("../assets/-icon-doc-star-alt.png")}
        wallet={require("../assets/wallet.png")}
        iconNotes={require("../assets/-icon-notes.png")}
        iconProfileCircled={require("../assets/-icon-profile-circled.png")}
        propColor="#3f5bd9"
        propColor1="#aab2bd"
      />
    </View>
  );
};

const styles = StyleSheet.create({
  frameLayout: {
    height: 6,
    width: 6,
  },
  liveFlexBox: {
    padding: Padding.p_3xs,
    justifyContent: "center",
    flexDirection: "row",
    alignItems: "center",
  },
  live1Typo: {
    textAlign: "center",
    fontFamily: FontFamily.interRegular,
  },
  maskGroup11: {
    borderRadius: Border.br_3xs,
    height: 67,
    marginTop: 8,
    width: 336,
  },
  frameItem: {
    marginLeft: 6,
  },
  ellipseParent: {
    justifyContent: "center",
    flexDirection: "row",
    marginTop: 8,
    width: 336,
    alignItems: "center",
  },
  explore1: {
    color: Color.colorWhite,
    fontSize: FontSize.size_3xs,
    textAlign: "center",
    fontFamily: FontFamily.interRegular,
    flex: 1,
  },
  explore: {
    backgroundColor: Color.colorDarkgray,
    width: 56,
    height: 20,
    borderRadius: Border.br_9xs,
    padding: Padding.p_3xs,
  },
  live1: {
    color: Color.colorWhite,
    fontSize: FontSize.size_3xs,
    textAlign: "center",
    fontFamily: FontFamily.interRegular,
  },
  live: {
    backgroundColor: Color.colorRoyalblue,
    height: 20,
    borderRadius: Border.br_9xs,
    padding: Padding.p_3xs,
  },
  exploreParent: {
    alignSelf: "stretch",
    flexDirection: "row",
    marginTop: 8,
    justifyContent: "space-between",
  },
  liveGames: {
    fontSize: FontSize.size_sm,
    fontWeight: "600",
    fontFamily: FontFamily.interSemiBold,
    color: Color.colorBlack,
    textAlign: "left",
    flex: 1,
  },
  viewMore1: {
    fontSize: FontSize.size_4xs_5,
    color: Color.colorRoyalblue,
    textAlign: "center",
    fontFamily: FontFamily.interRegular,
  },
  viewMoreChild: {
    width: 4,
    height: 7,
    marginLeft: 4,
  },
  viewMore: {
    marginLeft: 10,
    flexDirection: "row",
    alignItems: "center",
  },
  liveGamesParent: {
    width: 337,
    height: 22,
    marginTop: 8,
  },
  frameParent: {
    paddingHorizontal: 0,
    paddingVertical: Padding.p_5xs,
    alignItems: "center",
    flex: 1,
  },
  cricketHomePageLive: {
    backgroundColor: Color.colorGhostwhite,
    width: "100%",
    height: 800,
    justifyContent: "space-between",
    alignItems: "center",
    flex: 1,
  },
});

export default CricketHomePageLive;
