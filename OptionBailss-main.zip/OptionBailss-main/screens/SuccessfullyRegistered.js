import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View } from "react-native";
import { Color, FontSize, FontFamily, Border } from "../GlobalStyles";

const SuccessfullyRegistered = () => {
  return (
    <View style={styles.successfullyRegistered}>
      <Image
        style={[styles.successfullyRegisteredChild, styles.goToLoginPosition]}
        contentFit="cover"
        source={require("../assets/rectangle-44.png")}
      />
      <View style={[styles.groupParent, styles.goToLoginPosition]}>
        <View style={styles.ellipseParent}>
          <Image
            style={[styles.groupChild, styles.mediumBtnPosition]}
            contentFit="cover"
            source={require("../assets/ellipse-48.png")}
          />
          <Image
            style={styles.outlineIcon}
            contentFit="cover"
            source={require("../assets/outline1.png")}
          />
          <Image
            style={[styles.groupItem, styles.groupLayout]}
            contentFit="cover"
            source={require("../assets/ellipse-49.png")}
          />
          <Image
            style={[styles.groupInner, styles.groupLayout]}
            contentFit="cover"
            source={require("../assets/ellipse-49.png")}
          />
          <Text style={[styles.text, styles.textTypo]}>+</Text>
          <Text style={[styles.text1, styles.textTypo]}>+</Text>
        </View>
        <Text style={styles.successfullyRegistered1}>{`Successfully
Registered`}</Text>
        <Text style={[styles.congratulationsYouHave, styles.goToLoginTypo]}>{`
Congratulations, 
You have successfully registered.`}</Text>
        <View style={[styles.mediumBtnParent, styles.mediumLayout]}>
          <View style={[styles.mediumBtn, styles.mediumLayout]}>
            <View style={styles.mediumBtnChild} />
          </View>
          <Text style={[styles.goToLogin, styles.goToLoginTypo]}>
            Go to Login
          </Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  goToLoginPosition: {
    left: "50%",
    top: "50%",
    position: "absolute",
  },
  mediumBtnPosition: {
    top: 0,
    position: "absolute",
  },
  groupLayout: {
    height: 12,
    width: 12,
    position: "absolute",
  },
  textTypo: {
    textShadowRadius: 2,
    textShadowOffset: {
      width: 0,
      height: 1,
    },
    textShadowColor: "#0866ff",
    color: Color.colorRoyalblue,
    fontSize: FontSize.size_mini,
    textAlign: "center",
    fontFamily: FontFamily.interSemiBold,
    fontWeight: "600",
    position: "absolute",
  },
  goToLoginTypo: {
    fontSize: FontSize.size_sm,
    textAlign: "center",
  },
  mediumLayout: {
    height: 58,
    width: 200,
  },
  successfullyRegisteredChild: {
    marginTop: -194,
    marginLeft: -152,
    borderRadius: 20,
    width: 300,
    height: 400,
  },
  groupChild: {
    width: 80,
    height: 80,
    left: 8,
  },
  outlineIcon: {
    top: 33,
    left: 37,
    borderRadius: 1,
    width: 22,
    height: 15,
    position: "absolute",
  },
  groupItem: {
    top: 5,
    left: 83,
  },
  groupInner: {
    top: 70,
    left: 8,
  },
  text: {
    top: 50,
    left: 0,
  },
  text1: {
    top: 19,
    left: 87,
  },
  ellipseParent: {
    width: 98,
    height: 82,
  },
  successfullyRegistered1: {
    fontSize: FontSize.size_6xl,
    color: Color.colorBlack,
    marginTop: 19,
    textAlign: "center",
    fontFamily: FontFamily.interSemiBold,
    fontWeight: "600",
  },
  congratulationsYouHave: {
    color: Color.colorDarkgray,
    marginTop: 19,
    fontFamily: FontFamily.interSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_sm,
  },
  mediumBtnChild: {
    height: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    borderRadius: Border.br_9xs,
    backgroundColor: Color.colorRoyalblue,
    position: "absolute",
    width: "100%",
  },
  mediumBtn: {
    left: 0,
    top: 0,
    position: "absolute",
  },
  goToLogin: {
    marginTop: -9,
    marginLeft: -42,
    fontWeight: "700",
    fontFamily: FontFamily.interBold,
    color: Color.colorWhite,
    left: "50%",
    top: "50%",
    position: "absolute",
  },
  mediumBtnParent: {
    marginTop: 19,
  },
  groupParent: {
    marginTop: -151,
    marginLeft: -117,
    alignItems: "center",
    justifyContent: "center",
  },
  successfullyRegistered: {
    backgroundColor: Color.colorGhostwhite,
    flex: 1,
    height: 800,
    overflow: "hidden",
    width: "100%",
  },
});

export default SuccessfullyRegistered;
