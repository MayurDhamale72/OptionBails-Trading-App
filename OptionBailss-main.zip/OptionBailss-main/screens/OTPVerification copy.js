import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Image } from "expo-image";
import Back from "../components/Back";
import VerifyCodeForm from "../components/VerifyCodeForm";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const OTPVerification = () => {
  return (
    <View style={styles.otpVerification}>
      <View style={styles.backParent}>
        <Back />
        <Text style={styles.verifyCode}>Verify Code</Text>
      </View>
      <VerifyCodeForm />
    </View>
  );
};

const styles = StyleSheet.create({
  verifyCode: {
    fontSize: FontSize.size_sm,
    fontWeight: "600",
    fontFamily: FontFamily.interSemiBold,
    color: Color.colorDarkgray,
    textAlign: "center",
    marginLeft: 29,
  },
  backParent: {
    position: "absolute",
    top: 59,
    left: 30,
    flexDirection: "row",
    alignItems: "center",
  },
  otpVerification: {
    backgroundColor: Color.colorGhostwhite,
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
  },
});

export default OTPVerification;
