import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import SectionWithBailsForm from "../components/SectionWithBailsForm";
import SectionHokey from "../components/SectionHokey";
import SectionWithNumbers from "../components/SectionWithNumbers";
import SectionRealisedGainForm from "../components/SectionRealisedGainForm";
import Property1on from "../components/Property1on";
import Property1off5 from "../components/Property1off5";
import Property1off6 from "../components/Property1off6";
import Property1off7 from "../components/Property1off7";
import Property1off8 from "../components/Property1off8";
import Section from "../components/Section";
import Section2 from "../components/Section2";
import { Border, FontSize, FontFamily, Color, Padding } from "../GlobalStyles";

const HokeyHomePageExplore = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.hokeyHomePageExplore}>
      <SectionWithBailsForm
        dimensionCode={require("../assets/group-733.png")}
        productCode={require("../assets/group-741.png")}
      />
      <View style={styles.frameParent}>
        <SectionHokey
          vector={require("../assets/vector4.png")}
          group60={require("../assets/group-602.png")}
          onCricketPress={() => navigation.navigate("CricketHomePageExplore")}
          onFootballPress={() => navigation.navigate("FootballHomePageExplore")}
          onBasketballPress={() =>
            navigation.navigate("BasketballHomePageExplore")
          }
          onBaseballPress={() => navigation.navigate("BaseballHomePageExplore")}
        />
        <Image
          style={styles.maskGroup11}
          contentFit="cover"
          source={require("../assets/mask-group-1-1.png")}
        />
        <View style={[styles.ellipseParent, styles.parentFlexBox]}>
          <Image
            style={styles.frameLayout}
            contentFit="cover"
            source={require("../assets/ellipse-541.png")}
          />
          <Image
            style={[styles.frameItem, styles.frameLayout]}
            contentFit="cover"
            source={require("../assets/ellipse-551.png")}
          />
          <Image
            style={[styles.frameItem, styles.frameLayout]}
            contentFit="cover"
            source={require("../assets/ellipse-551.png")}
          />
        </View>
        <SectionWithNumbers
          uniqueIdentifier={require("../assets/group-686.png")}
          uniqueIdentifierText={require("../assets/group-686.png")}
          dimensionText={require("../assets/group-687.png")}
        />
        <SectionRealisedGainForm />
        <View style={styles.exploreParent}>
          <Property1on property1onPosition="unset" />
          <Property1off5
            property1offPosition="unset"
            onLivePress={() => navigation.navigate("HokeyHomePageLive")}
          />
          <Property1off6
            property1offPosition="unset"
            onUpcomingPress={() => navigation.navigate("HokeyHomePageUpcoming")}
          />
          <Property1off7
            property1offPosition="unset"
            onCompletedPress={() =>
              navigation.navigate("HokeyHomePageCompleted")
            }
          />
          <Property1off8
            prizeAmount="Winnings"
            property1offPosition="unset"
            winningsFontSize={10}
            winningsFontFamily="Inter-Regular"
            winningsColor="#fff"
            winningsTextAlign="center"
            onWinningsPress={() => navigation.navigate("HokeyHomePageWinnings")}
          />
        </View>
        <View style={[styles.exploreHereParent, styles.parentFlexBox]}>
          <Text style={styles.exploreHere}>Explore Here</Text>
          <Image
            style={styles.groupIcon}
            contentFit="cover"
            source={require("../assets/group-583.png")}
          />
        </View>
        <Section
          group81={require("../assets/group-82.png")}
          majesticonstShirtLine={require("../assets/majesticonstshirtline1.png")}
          majesticonstShirtLine1={require("../assets/majesticonstshirtline1.png")}
        />
      </View>
      <Section2
        group59={require("../assets/group-59.png")}
        iconDocStarAlt={require("../assets/-icon-doc-star-alt.png")}
        wallet={require("../assets/wallet.png")}
        iconNotes={require("../assets/-icon-notes.png")}
        iconProfileCircled={require("../assets/-icon-profile-circled.png")}
        propColor="#3f5bd9"
        propColor1="#aab2bd"
      />
    </View>
  );
};

const styles = StyleSheet.create({
  parentFlexBox: {
    justifyContent: "center",
    flexDirection: "row",
    marginTop: 8,
    alignItems: "center",
  },
  frameLayout: {
    height: 6,
    width: 6,
  },
  maskGroup11: {
    borderRadius: Border.br_3xs,
    height: 67,
    marginTop: 8,
    width: 336,
  },
  frameItem: {
    marginLeft: 6,
  },
  ellipseParent: {
    width: 336,
    justifyContent: "center",
  },
  exploreParent: {
    alignSelf: "stretch",
    flexDirection: "row",
    marginTop: 8,
    justifyContent: "space-between",
  },
  exploreHere: {
    fontSize: FontSize.size_sm,
    fontWeight: "600",
    fontFamily: FontFamily.interSemiBold,
    color: Color.colorBlack,
    textAlign: "left",
    flex: 1,
  },
  groupIcon: {
    width: 20,
    height: 20,
    marginLeft: 10,
  },
  exploreHereParent: {
    width: 337,
    height: 22,
    padding: Padding.p_3xs,
  },
  frameParent: {
    paddingHorizontal: 0,
    paddingVertical: Padding.p_5xs,
    alignItems: "center",
    flex: 1,
  },
  hokeyHomePageExplore: {
    backgroundColor: Color.colorGhostwhite,
    width: "100%",
    height: 800,
    justifyContent: "space-between",
    alignItems: "center",
    flex: 1,
  },
});

export default HokeyHomePageExplore;
