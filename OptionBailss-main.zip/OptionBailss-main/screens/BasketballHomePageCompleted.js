import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import SectionWithBailsForm from "../components/SectionWithBailsForm";
import Property1off from "../components/Property1off";
import Property1off1 from "../components/Property1off1";
import Property1off3 from "../components/Property1off3";
import Property1off4 from "../components/Property1off4";
import SectionWithNumbers from "../components/SectionWithNumbers";
import SectionRealisedGainForm from "../components/SectionRealisedGainForm";
import Property1off5 from "../components/Property1off5";
import Property1off6 from "../components/Property1off6";
import Property1off8 from "../components/Property1off8";
import MatchupSection from "../components/MatchupSection";
import Section2 from "../components/Section2";
import { Color, FontFamily, Padding, FontSize, Border } from "../GlobalStyles";

const BasketballHomePageCompleted = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.basketballHomePageCompleted}>
      <SectionWithBailsForm
        dimensionCode={require("../assets/group-733.png")}
        productCode={require("../assets/group-741.png")}
      />
      <View style={styles.frameParent}>
        <Pressable
          style={styles.parentFlexBox}
          onPress={() => navigation.navigate("BasketballHomePageExplore")}
        >
          <Property1off
            dimensionsCode={require("../assets/vector2.png")}
            property1offPosition="unset"
            onCricketPress={() => navigation.navigate("CricketHomePageExplore")}
          />
          <Property1off1
            dimensionCode={require("../assets/group-22.png")}
            property1offPosition="unset"
            property1offMarginLeft={35}
            onFootballPress={() =>
              navigation.navigate("FootballHomePageExplore")
            }
          />
          <View style={styles.basketball}>
            <Image
              style={styles.vectorIcon}
              contentFit="cover"
              source={require("../assets/vector9.png")}
            />
            <Text style={[styles.basketball1, styles.viewMore1Typo]}>
              Basketball
            </Text>
            <View style={styles.basketballChild} />
          </View>
          <Property1off3
            productCode={require("../assets/vector4.png")}
            property1offPosition="unset"
            property1offMarginLeft={35}
            onBaseballPress={() =>
              navigation.navigate("BaseballHomePageExplore")
            }
          />
          <Property1off4
            group60={require("../assets/group-60.png")}
            property1offPosition="unset"
            property1offMarginLeft={35}
            onHokeyPress={() => navigation.navigate("HokeyHomePageExplore")}
          />
        </Pressable>
        <Image
          style={styles.maskGroup11}
          contentFit="cover"
          source={require("../assets/mask-group-1-1.png")}
        />
        <View style={[styles.ellipseParent, styles.parentFlexBox]}>
          <Image
            style={styles.frameLayout}
            contentFit="cover"
            source={require("../assets/ellipse-541.png")}
          />
          <Image
            style={[styles.frameItem, styles.frameLayout]}
            contentFit="cover"
            source={require("../assets/ellipse-551.png")}
          />
          <Image
            style={[styles.frameItem, styles.frameLayout]}
            contentFit="cover"
            source={require("../assets/ellipse-551.png")}
          />
        </View>
        <SectionWithNumbers
          uniqueIdentifier={require("../assets/group-686.png")}
          uniqueIdentifierText={require("../assets/group-686.png")}
          dimensionText={require("../assets/group-687.png")}
        />
        <SectionRealisedGainForm />
        <View style={styles.exploreParent}>
          <Pressable
            style={[styles.explore, styles.completedFlexBox]}
            onPress={() => navigation.navigate("BasketballHomePageExplore")}
          >
            <Text style={[styles.explore1, styles.explore1Typo]}>Explore</Text>
          </Pressable>
          <Property1off5
            property1offPosition="unset"
            onLivePress={() => navigation.navigate("BasketballHomePageLive")}
          />
          <Property1off6
            property1offPosition="unset"
            onUpcomingPress={() =>
              navigation.navigate("BasketballHomePageUpcoming")
            }
          />
          <View style={[styles.completed, styles.completedFlexBox]}>
            <Text style={styles.explore1Typo}>Completed</Text>
          </View>
          <Property1off8
            prizeAmount="Winnings"
            property1offPosition="unset"
            winningsFontSize={10}
            winningsFontFamily="Inter-Regular"
            winningsColor="#fff"
            winningsTextAlign="center"
            onWinningsPress={() =>
              navigation.navigate("BasketballHomePageWinnings")
            }
          />
        </View>
        <View style={[styles.completedGamesParent, styles.completedFlexBox]}>
          <Text style={styles.completedGames}>Completed Games</Text>
          <View style={styles.viewMore}>
            <Text style={[styles.viewMore1, styles.viewMore1Typo]}>
              VIEW MORE
            </Text>
            <Image
              style={styles.viewMoreChild}
              contentFit="cover"
              source={require("../assets/group-673.png")}
            />
          </View>
        </View>
        <MatchupSection
          eNG="ENG"
          iNDVsENG="IND Vs ENG"
          group68={require("../assets/group-688.png")}
          iND="IND"
          majesticonstShirtLine={require("../assets/majesticonstshirtline1.png")}
          propAlignSelf="stretch"
        />
        <MatchupSection
          eNG="PAK"
          iNDVsENG="PAK Vs SA"
          group68={require("../assets/group-686.png")}
          iND="SA"
          majesticonstShirtLine={require("../assets/majesticonstshirtline1.png")}
          propAlignSelf="stretch"
        />
      </View>
      <Section2
        group59={require("../assets/group-59.png")}
        iconDocStarAlt={require("../assets/-icon-doc-star-alt.png")}
        wallet={require("../assets/wallet4.png")}
        iconNotes={require("../assets/-icon-notes.png")}
        iconProfileCircled={require("../assets/-icon-profile-circled.png")}
        propColor="#3f5bd9"
        propColor1="#aab2bd"
      />
    </View>
  );
};

const styles = StyleSheet.create({
  viewMore1Typo: {
    textAlign: "center",
    color: Color.colorRoyalblue,
    fontFamily: FontFamily.interRegular,
  },
  parentFlexBox: {
    justifyContent: "center",
    flexDirection: "row",
    width: 336,
    alignItems: "center",
  },
  frameLayout: {
    height: 6,
    width: 6,
  },
  completedFlexBox: {
    padding: Padding.p_3xs,
    justifyContent: "center",
    flexDirection: "row",
    alignItems: "center",
  },
  explore1Typo: {
    color: Color.colorWhite,
    textAlign: "center",
    fontFamily: FontFamily.interRegular,
    fontSize: FontSize.size_3xs,
  },
  vectorIcon: {
    width: 20,
    height: 20,
  },
  basketball1: {
    marginTop: 3,
    fontSize: FontSize.size_3xs,
    color: Color.colorRoyalblue,
    fontFamily: FontFamily.interRegular,
  },
  basketballChild: {
    width: 49,
    height: 3,
    backgroundColor: Color.colorRoyalblue,
    marginTop: 3,
  },
  basketball: {
    marginLeft: 35,
    alignItems: "center",
  },
  maskGroup11: {
    borderRadius: Border.br_3xs,
    height: 67,
    marginTop: 8,
    width: 336,
  },
  frameItem: {
    marginLeft: 6,
  },
  ellipseParent: {
    marginTop: 8,
  },
  explore1: {
    flex: 1,
  },
  explore: {
    backgroundColor: Color.colorDarkgray,
    width: 56,
    borderRadius: Border.br_9xs,
    padding: Padding.p_3xs,
    height: 20,
  },
  completed: {
    borderRadius: Border.br_9xs,
    padding: Padding.p_3xs,
    height: 20,
    backgroundColor: Color.colorRoyalblue,
  },
  exploreParent: {
    alignSelf: "stretch",
    marginTop: 8,
    flexDirection: "row",
    justifyContent: "space-between",
  },
  completedGames: {
    fontSize: FontSize.size_sm,
    fontWeight: "600",
    fontFamily: FontFamily.interSemiBold,
    color: Color.colorBlack,
    textAlign: "left",
    flex: 1,
  },
  viewMore1: {
    fontSize: FontSize.size_4xs_5,
  },
  viewMoreChild: {
    width: 4,
    height: 7,
    marginLeft: 4,
  },
  viewMore: {
    marginLeft: 10,
    flexDirection: "row",
    alignItems: "center",
  },
  completedGamesParent: {
    width: 337,
    height: 22,
    marginTop: 8,
  },
  frameParent: {
    paddingHorizontal: 0,
    paddingVertical: Padding.p_5xs,
    alignItems: "center",
    flex: 1,
  },
  basketballHomePageCompleted: {
    backgroundColor: Color.colorGhostwhite,
    width: "100%",
    height: 800,
    justifyContent: "space-between",
    alignItems: "center",
    flex: 1,
  },
});

export default BasketballHomePageCompleted;
