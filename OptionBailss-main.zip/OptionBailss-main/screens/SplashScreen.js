import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import { Color, FontFamily, FontSize } from "../GlobalStyles";

const SplashScreen = () => {
  return (
    <View style={styles.splashScreen}>
      <View style={styles.groupParentFlexBox}>
        <View style={styles.groupContainer}>
          <View style={[styles.bailsParent, styles.optionLayout]}>
            <Text style={[styles.bails, styles.bailsTypo]}> BAILS</Text>
            <Text style={[styles.option, styles.bailsTypo]}>OPTION</Text>
          </View>
          <Image
            style={styles.vectorIcon}
            contentFit="cover"
            source={require("../assets/vector.png")}
          />
          <Image
            style={[styles.groupChild, styles.groupLayout]}
            contentFit="cover"
            source={require("../assets/group-73.png")}
          />
          <Image
            style={[styles.groupItem, styles.groupLayout]}
            contentFit="cover"
            source={require("../assets/group-74.png")}
          />
        </View>
        <View
          style={[styles.letsTradeTheGameWrapper, styles.groupParentFlexBox]}
        >
          <Text style={styles.letsTradeThe}>Lets trade the game!</Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  optionLayout: {
    width: 83,
    top: 0,
  },
  bailsTypo: {
    height: 27,
    textAlign: "center",
    color: Color.colorWhite,
    fontFamily: FontFamily.cambayBold,
    fontWeight: "700",
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  groupLayout: {
    height: 19,
    width: 16,
    position: "absolute",
  },
  groupParentFlexBox: {
    justifyContent: "center",
    alignSelf: "stretch",
    alignItems: "center",
  },
  bails: {
    top: 15,
    width: 63,
    left: 8,
  },
  option: {
    left: 0,
    width: 83,
    top: 0,
  },
  bailsParent: {
    left: 26,
    position: "absolute",
    height: 42,
  },
  vectorIcon: {
    top: 17,
    width: 20,
    height: 20,
    left: 8,
    position: "absolute",
  },
  groupChild: {
    top: 7,
    left: 0,
  },
  groupItem: {
    top: 1,
    left: 14,
  },
  groupContainer: {
    width: 109,
    height: 42,
  },
  letsTradeThe: {
    textAlign: "center",
    color: Color.colorWhite,
    fontFamily: FontFamily.cambayBold,
    fontWeight: "700",
    fontSize: FontSize.size_xl,
  },
  letsTradeTheGameWrapper: {
    flexDirection: "row",
  },
  splashScreen: {
    backgroundColor: Color.colorRoyalblue,
    flex: 1,
    width: "100%",
    height: 800,
    justifyContent: "space-between",
    alignItems: "center",
  },
});

export default SplashScreen;
