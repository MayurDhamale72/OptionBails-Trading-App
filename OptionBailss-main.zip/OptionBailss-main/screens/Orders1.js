import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import SectionWithBailsForm from "../components/SectionWithBailsForm";
import PortfolioContainer from "../components/PortfolioContainer";
import Section2 from "../components/Section2";
import { Padding, Color, FontSize, FontFamily, Border } from "../GlobalStyles";

const Orders1 = () => {
  return (
    <View style={styles.orders4}>
      <View style={styles.frameParent}>
        <SectionWithBailsForm
          dimensionCode={require("../assets/group-731.png")}
          productCode={require("../assets/group-742.png")}
        />
        <View style={styles.openordersParent}>
          <View style={[styles.openorders, styles.positionsSpaceBlock]}>
            <Text style={styles.openOrders}>Open Orders</Text>
          </View>
          <View style={[styles.positions, styles.basketsFlexBox]}>
            <Text style={styles.openOrders}>Positions</Text>
          </View>
          <View style={[styles.baskets, styles.basketsFlexBox]}>
            <Text style={styles.openOrders}>Baskets</Text>
          </View>
          <View style={[styles.baskets, styles.basketsFlexBox]}>
            <Text style={styles.openOrders}>GTT</Text>
          </View>
        </View>
        <View style={styles.frameGroup}>
          <View
            style={[styles.openPositionsParent, styles.positionsSpaceBlock]}
          >
            <Text style={[styles.openPositions, styles.openPositionsFlexBox]}>
              Open Positions
            </Text>
            <View style={styles.basketsFlexBox}>
              <Text
                style={[styles.selectExit, styles.textTypo]}
              >{`SELECT & EXIT`}</Text>
              <Image
                style={styles.viewMoreChild}
                contentFit="cover"
                source={require("../assets/group-671.png")}
              />
            </View>
          </View>
          <PortfolioContainer
            group68={require("../assets/group-682.png")}
            group66={require("../assets/group-661.png")}
            group661={require("../assets/group-661.png")}
            group662={require("../assets/group-661.png")}
            investment="Investment"
            group663={require("../assets/group-661.png")}
            group664={require("../assets/group-661.png")}
            prop="32000"
          />
          <PortfolioContainer
            group68={require("../assets/group-682.png")}
            group66={require("../assets/group-661.png")}
            group661={require("../assets/group-661.png")}
            group662={require("../assets/group-661.png")}
            investment="Investment"
            group663={require("../assets/group-661.png")}
            group664={require("../assets/group-661.png")}
            prop="32000"
            thisGamesProfitMarginTop={10}
          />
        </View>
        <View style={styles.frameGroup}>
          <View
            style={[styles.openPositionsParent, styles.positionsSpaceBlock]}
          >
            <Text style={[styles.openPositions, styles.openPositionsFlexBox]}>
              Closed Positions
            </Text>
          </View>
          <PortfolioContainer
            group68={require("../assets/group-682.png")}
            group66={require("../assets/group-661.png")}
            group661={require("../assets/group-661.png")}
            group662={require("../assets/group-661.png")}
            investment="Investment"
            group663={require("../assets/group-661.png")}
            group664={require("../assets/group-661.png")}
            prop="32000"
            thisGamesProfitMarginTop={10}
          />
          <PortfolioContainer
            group68={require("../assets/group-682.png")}
            group66={require("../assets/group-661.png")}
            group661={require("../assets/group-661.png")}
            group662={require("../assets/group-661.png")}
            investment="Investment"
            group663={require("../assets/group-661.png")}
            group664={require("../assets/group-661.png")}
            prop="32000"
            thisGamesProfitMarginTop={10}
          />
        </View>
      </View>
      <View style={styles.frameView}>
        <View style={styles.watchlistObj1Wrapper}>
          <View style={styles.watchlistObj1}>
            <View style={styles.totalGainlossWrapper}>
              <Text style={[styles.totalGainloss, styles.openPositionsFlexBox]}>
                Total Gain/Loss
              </Text>
            </View>
            <View style={styles.price}>
              <View style={styles.groupParent}>
                <Image
                  style={styles.frameChild}
                  contentFit="cover"
                  source={require("../assets/group-672.png")}
                />
                <Text style={[styles.text, styles.textTypo]}>15700</Text>
                <Image
                  style={styles.frameItem}
                  contentFit="cover"
                  source={require("../assets/group-683.png")}
                />
              </View>
            </View>
          </View>
        </View>
        <Section2
          group59={require("../assets/group-593.png")}
          iconDocStarAlt={require("../assets/-icon-doc-star-alt2.png")}
          wallet={require("../assets/wallet2.png")}
          iconNotes={require("../assets/-icon-notes3.png")}
          iconProfileCircled={require("../assets/-icon-profile-circled2.png")}
          propColor="#aab2bd"
          propColor1="#3f5bd9"
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  positionsSpaceBlock: {
    padding: Padding.p_3xs,
    justifyContent: "center",
  },
  basketsFlexBox: {
    marginLeft: 10,
    flexDirection: "row",
    alignItems: "center",
  },
  openPositionsFlexBox: {
    textAlign: "left",
    color: Color.colorBlack,
  },
  textTypo: {
    fontSize: FontSize.size_4xs_5,
    textAlign: "center",
    fontFamily: FontFamily.interRegular,
  },
  openOrders: {
    fontSize: FontSize.size_3xs,
    color: Color.colorWhite,
    textAlign: "center",
    fontFamily: FontFamily.interRegular,
  },
  openorders: {
    height: 20,
    borderRadius: Border.br_9xs,
    padding: Padding.p_3xs,
    flex: 1,
    backgroundColor: Color.colorDarkgray,
    flexDirection: "row",
    alignItems: "center",
  },
  positions: {
    backgroundColor: Color.colorRoyalblue,
    padding: Padding.p_3xs,
    justifyContent: "center",
    height: 20,
    borderRadius: Border.br_9xs,
    flex: 1,
    marginLeft: 10,
  },
  baskets: {
    padding: Padding.p_3xs,
    justifyContent: "center",
    height: 20,
    borderRadius: Border.br_9xs,
    flex: 1,
    backgroundColor: Color.colorDarkgray,
  },
  openordersParent: {
    marginTop: 5,
    alignItems: "flex-end",
    flexDirection: "row",
    alignSelf: "stretch",
  },
  openPositions: {
    fontSize: FontSize.size_sm,
    fontWeight: "600",
    fontFamily: FontFamily.interSemiBold,
    flex: 1,
  },
  selectExit: {
    color: Color.colorRoyalblue,
  },
  viewMoreChild: {
    width: 4,
    height: 7,
    marginLeft: 4,
  },
  openPositionsParent: {
    width: 337,
    height: 22,
    flexDirection: "row",
    alignItems: "center",
  },
  frameGroup: {
    paddingHorizontal: 0,
    paddingVertical: Padding.p_3xs,
    marginTop: 5,
  },
  frameParent: {
    alignSelf: "stretch",
    alignItems: "center",
  },
  totalGainloss: {
    fontSize: FontSize.size_xs,
    fontFamily: FontFamily.interRegular,
    textAlign: "left",
    color: Color.colorBlack,
  },
  totalGainlossWrapper: {
    width: 251,
    flexDirection: "row",
    alignItems: "center",
  },
  frameChild: {
    width: 5,
    height: 6,
  },
  text: {
    color: Color.green1,
    marginLeft: 3,
  },
  frameItem: {
    width: 7,
    marginLeft: 3,
    height: 6,
  },
  groupParent: {
    justifyContent: "flex-end",
    paddingHorizontal: Padding.p_3xs,
    paddingVertical: 0,
    flexDirection: "row",
    alignSelf: "stretch",
    alignItems: "center",
  },
  price: {
    height: 17,
    justifyContent: "center",
    alignItems: "flex-end",
    flex: 1,
  },
  watchlistObj1: {
    flexDirection: "row",
    alignSelf: "stretch",
    alignItems: "center",
  },
  watchlistObj1Wrapper: {
    justifyContent: "center",
    alignSelf: "stretch",
    backgroundColor: Color.colorGhostwhite,
  },
  frameView: {
    height: 83,
    alignSelf: "stretch",
    alignItems: "center",
  },
  orders4: {
    width: "100%",
    height: 800,
    justifyContent: "space-between",
    alignItems: "center",
    flex: 1,
    backgroundColor: Color.colorGhostwhite,
  },
});

export default Orders1;
