import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import SectionWithBailsForm from "../components/SectionWithBailsForm";
import Section1 from "../components/Section1";
import SectionWithNumbers from "../components/SectionWithNumbers";
import SectionRealisedGainForm from "../components/SectionRealisedGainForm";
import Property1on from "../components/Property1on";
import Property1off5 from "../components/Property1off5";
import Property1off6 from "../components/Property1off6";
import Property1off7 from "../components/Property1off7";
import Property1off8 from "../components/Property1off8";
import Section from "../components/Section";
import BottomNavigation from "../components/BottomNavigation";
import { Border, FontSize, FontFamily, Color, Padding } from "../GlobalStyles";


import { SliderBox } from 'react-native-image-slider-box';
import { ScrollView } from "react-native";


const MainHomeScreen = () => {
  const navigation = useNavigation();

  const image = [
    require("../assets/mask-group-1-1.png"),
    require("../assets/mask-group-1-1.png"),
    require("../assets/mask-group-1-1.png"),
  ];



  return (

    <View style={styles.homePageExplore}>
      <SectionWithBailsForm
        dimensionCode={require("../assets/group-731.png")}
        productCode={require("../assets/group-741.png")}
      />
      <View style={styles.frameParent}>
        <Section1
          dimensionCode={require("../assets/vector2.png")}
          dimensionCodeText={require("../assets/group-2.png")}
          dimensionCodeId={require("../assets/vector3.png")}
          dimensionCodeValue={require("../assets/group-60.png")}
          onCricketPress={() => navigation.navigate("CricketHomePageExplore")}
          onFootballPress={() => navigation.navigate("FootballHomePageExplore")}
          onBasketballPress={() =>
            navigation.navigate("BasketballHomePageExplore")
          }
          onBaseballPress={() => navigation.navigate("BaseballHomePageExplore")}
          onHokeyPress={() => navigation.navigate("HokeyHomePageExplore")}
        />
        <ScrollView>
          {/* shorting format image */}
          {/* <Image
            style={styles.maskGroup11}
            contentFit="cover"
            source={require("../assets/mask-group-1-1.png")}
          /> */}



          <View style={[styles.ellipseParent, styles.parentFlexBox , styles.sliderContainer]}>
            {/* <Image
              style={styles.frameLayout}
              contentFit="cover"
              source={require("../assets/ellipse-54.png")}
            />
            <Image
              style={[styles.frameItem, styles.frameLayout]}
              contentFit="cover"
              source={require("../assets/ellipse-55.png")}
            />
            <Image
              style={[styles.frameItem, styles.frameLayout]}
              contentFit="cover"
              source={require("../assets/ellipse-55.png")}
            /> */}
            <SliderBox
              images={image}
              style={styles.maskGroup11}
              dotColor="black"
              inactiveDotColor="lightgrey"
              dotStyle={{ height: 7, width: 7, borderRadius: 50 }}
              autoplay={true}
              autoplayInterval={4000}
              circleLoop={true}
              paginationBoxVerticalPadding={-11}
            />
          </View>
          <SectionWithNumbers
            uniqueIdentifier={require("../assets/group-68.png")}
            uniqueIdentifierText={require("../assets/group-68.png")}
            dimensionText={require("../assets/group-681.png")}
          />
          <SectionRealisedGainForm />
          <View style={styles.exploreParent}>
            <Property1on property1onPosition="unset" />
            <Property1off5
              property1offPosition="unset"
              onLivePress={() => navigation.navigate("HomePageLive")}
            />
            <Property1off6
              property1offPosition="unset"
              onUpcomingPress={() => navigation.navigate("HomePageUpcoming")}
            />
            <Property1off7
              property1offPosition="unset"
              onCompletedPress={() => navigation.navigate("HomePageCompleted")}
            />
            <Property1off8
              prizeAmount="Winnings"
              property1offPosition="unset"
              winningsFontSize={10}
              winningsFontFamily="Inter-Regular"
              winningsColor="#fff"
              winningsTextAlign="center"
              onWinningsPress={() => navigation.navigate("HomePageWinnings")}
            />
          </View>
          <View style={[styles.exploreHereParent, styles.parentFlexBox]}>
            <Text style={styles.exploreHere}>Explore Here</Text>
            <Image
              style={styles.groupIcon}
              contentFit="cover"
              source={require("../assets/group-581.png")}
            />
          </View>
          <Section
            group81={require("../assets/group-81.png")}
            majesticonstShirtLine={require("../assets/majesticonstshirtline.png")}
            majesticonstShirtLine1={require("../assets/majesticonstshirtline.png")}
          />
        </ScrollView>
      </View>

      <BottomNavigation
        onWatchlistPress={() => navigation.navigate("CreateWatchlist")}
        onPortfolioPress={() => navigation.navigate("Portfolio")}
        onOrdersPress={() => navigation.navigate("Orders")}
      />
    </View>

  );
};

const styles = StyleSheet.create({
  parentFlexBox: {
    justifyContent: "center",
    flexDirection: "row",
    marginTop: 8,
    marginBottom: 8,
    // alignItems: "center",
  },
  sliderContainer: {
    alignItems: 'center', // Center the SliderBox horizontally
    marginBottom: 20, // Add some space between the SliderBox and other content below
  },
  frameLayout: {
    height: 6,
    width: 6,
  },
  maskGroup11: {
    borderRadius: Border.br_3xs,
    height: 60,
    marginTop: 8,
    width: 330,
    // borderRadius: 10,
  },
  frameItem: {
    marginLeft: 6,
  },
  ellipseParent: {
    
    width: 336,
    justifyContent: "center",
  },
  exploreParent: {
    alignSelf: "stretch",
    flexDirection: "row",
    marginTop: 8,
    justifyContent: "space-between",
  },
  exploreHere: {
    fontSize: FontSize.size_sm,
    fontWeight: "600",
    fontFamily: FontFamily.interSemiBold,
    color: Color.colorBlack,
    textAlign: "left",
    flex: 1,
  },
  groupIcon: {
    width: 20,
    height: 20,
    marginLeft: 10,
  },
  exploreHereParent: {
    width: 337,
    height: 22,
    padding: Padding.p_3xs,
  },
  frameParent: {
    paddingHorizontal: 0,
    paddingVertical: Padding.p_5xs,
    alignItems: "center",
    flex: 1,
  },
  homePageExplore: {
    backgroundColor: Color.colorGhostwhite,
    width: "100%",
    height: 800,
    justifyContent: "space-between",
    alignItems: "center",
    flex: 1,
  },
});

export default MainHomeScreen;
