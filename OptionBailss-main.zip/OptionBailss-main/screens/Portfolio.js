import * as React from "react";
import { Text, StyleSheet, View, Pressable } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import SectionWithBailsForm from "../components/SectionWithBailsForm";
import PortfolioContainer from "../components/PortfolioContainer";
import Property1off9 from "../components/Property1off9";
import Property1off11 from "../components/Property1off11";
import Property1off12 from "../components/Property1off12";
import { FontFamily, FontSize, Color, Padding } from "../GlobalStyles";
import BottomNavigation from "../components/BottomNavigation";

const Portfolio = () => {
  const navigation = useNavigation();
  
  
  return (
    <View style={styles.portfolio}>
      <View style={styles.frameParent}>
        <SectionWithBailsForm
          dimensionCode={require("../assets/group-731.png")}
          productCode={require("../assets/group-741.png")}
        />
        <View style={styles.portfolioSearchBar}>
          <Text style={styles.portfolio1}>Portfolio</Text>
          <Image
            style={styles.portfolioSearchBarChild}
            contentFit="cover"
            source={require("../assets/group-582.png")}
          />
        </View>
      </View>
      <View style={styles.portfolioobj1Parent}>
        <PortfolioContainer
          group68={require("../assets/group-684.png")}
          group66={require("../assets/group-662.png")}
          group661={require("../assets/group-662.png")}
          group662={require("../assets/group-662.png")}
          investment="Invested"
          group663={require("../assets/group-662.png")}
          group664={require("../assets/group-662.png")}
          prop="35000"
          thisGamesProfitMarginTop="unset"
        />
        <PortfolioContainer
          group68={require("../assets/group-684.png")}
          group66={require("../assets/group-662.png")}
          group661={require("../assets/group-662.png")}
          group662={require("../assets/group-662.png")}
          investment="Invested"
          group663={require("../assets/group-662.png")}
          group664={require("../assets/group-662.png")}
          prop="35000"
          thisGamesProfitMarginTop={10}
        />
        <PortfolioContainer
          group68={require("../assets/group-684.png")}
          group66={require("../assets/group-662.png")}
          group661={require("../assets/group-662.png")}
          group662={require("../assets/group-662.png")}
          investment="Invested"
          group663={require("../assets/group-662.png")}
          group664={require("../assets/group-662.png")}
          prop="35000"
          thisGamesProfitMarginTop={10}
        />
        <PortfolioContainer
          group68={require("../assets/group-684.png")}
          group66={require("../assets/group-662.png")}
          group661={require("../assets/group-662.png")}
          group662={require("../assets/group-662.png")}
          investment="Invested"
          group663={require("../assets/group-662.png")}
          group664={require("../assets/group-662.png")}
          prop="35000"
          thisGamesProfitMarginTop={10}
        />
        <PortfolioContainer
          group68={require("../assets/group-684.png")}
          group66={require("../assets/group-662.png")}
          group661={require("../assets/group-662.png")}
          group662={require("../assets/group-662.png")}
          investment="Invested"
          group663={require("../assets/group-662.png")}
          group664={require("../assets/group-662.png")}
          prop="35000"
          thisGamesProfitMarginTop={10}
        />
      </View>
     <BottomNavigation />
    </View>
  );
};

const styles = StyleSheet.create({
  home1Typo: {
    textAlign: "center",
    fontFamily: FontFamily.interRegular,
    fontSize: FontSize.size_3xs,
    marginTop: 5,
  },
  portfolio1: {
    fontSize: FontSize.size_sm,
    fontWeight: "600",
    fontFamily: FontFamily.interSemiBold,
    color: Color.colorBlack,
    textAlign: "left",
    flex: 1,
  },
  portfolioSearchBarChild: {
    height: 20,
    marginLeft: 10,
    width: 20,
  },
  portfolioSearchBar: {
    height: 22,
    padding: Padding.p_3xs,
    marginTop: 5,
    justifyContent: "center",
    flexDirection: "row",
    alignSelf: "stretch",
    alignItems: "center",
  },
  frameParent: {
    height: 110,
    alignSelf: "stretch",
    alignItems: "center",
  },
  portfolioobj1Parent: {
    alignItems: "flex-end",
  },
  homeChild: {
    height: 18,
    width: 20,
  },
  home1: {
    color: Color.colorDarkgray,
  },
  home: {
    alignItems: "center",
  },
  portfolio3: {
    color: Color.colorRoyalblue,
  },
  portfolio2: {
    marginLeft: 25,
    alignItems: "center",
  },
  homeParent: {
    backgroundColor: Color.colorWhite,
    paddingHorizontal: 0,
    paddingVertical: Padding.p_mini,
    justifyContent: "center",
    flexDirection: "row",
    alignSelf: "stretch",
    alignItems: "center",
  },
  portfolio: {
    backgroundColor: Color.colorGhostwhite,
    width: "100%",
    height: 800,
    justifyContent: "space-between",
    alignItems: "center",
    flex: 1,
  },
});

export default Portfolio;
