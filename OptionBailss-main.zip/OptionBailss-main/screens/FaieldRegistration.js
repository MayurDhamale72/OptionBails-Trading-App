import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Image } from "expo-image";
import { Color, FontSize, FontFamily, Border } from "../GlobalStyles";

const FaieldRegistration = () => {
  return (
    <View style={styles.faieldRegistration}>
      <View style={[styles.faieldRegistrationChild, styles.tryAgainPosition]} />
      <View style={[styles.groupParent, styles.tryAgainPosition]}>
        <View style={styles.ellipseParent}>
          <Image
            style={[styles.groupChild, styles.mediumBtnPosition]}
            contentFit="cover"
            source={require("../assets/ellipse-481.png")}
          />
          <Image
            style={styles.outlineIcon}
            contentFit="cover"
            source={require("../assets/outline1.png")}
          />
          <Image
            style={[styles.groupItem, styles.groupLayout]}
            contentFit="cover"
            source={require("../assets/ellipse-491.png")}
          />
          <Image
            style={[styles.groupInner, styles.groupLayout]}
            contentFit="cover"
            source={require("../assets/ellipse-491.png")}
          />
          <Text style={[styles.text, styles.textTypo]}>+</Text>
          <Text style={[styles.text1, styles.textTypo]}>+</Text>
        </View>
        <Text style={styles.failedToRegister}>{`Failed to
Register`}</Text>
        <Text style={[styles.sorryYourAccount, styles.tryAgainTypo]}>{`
Sorry, 
Your account failed to registered.`}</Text>
        <View style={[styles.mediumBtnParent, styles.mediumLayout]}>
          <View style={[styles.mediumBtn, styles.mediumLayout]}>
            <View style={styles.mediumBtnChild} />
          </View>
          <Text style={[styles.tryAgain, styles.tryAgainTypo]}>Try Again</Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  tryAgainPosition: {
    left: "50%",
    top: "50%",
    position: "absolute",
  },
  mediumBtnPosition: {
    top: 0,
    position: "absolute",
  },
  groupLayout: {
    height: 12,
    width: 12,
    position: "absolute",
  },
  textTypo: {
    textShadowRadius: 2,
    textShadowOffset: {
      width: 0,
      height: 1,
    },
    textShadowColor: "#d54d4c",
    color: Color.colorIndianred,
    fontSize: FontSize.size_mini,
    textAlign: "center",
    fontFamily: FontFamily.interSemiBold,
    fontWeight: "600",
    position: "absolute",
  },
  tryAgainTypo: {
    fontSize: FontSize.size_sm,
    textAlign: "center",
  },
  mediumLayout: {
    height: 58,
    width: 200,
  },
  faieldRegistrationChild: {
    marginTop: -194,
    marginLeft: -152,
    borderRadius: Border.br_xl,
    backgroundColor: Color.colorWhite,
    width: 300,
    height: 400,
  },
  groupChild: {
    width: 80,
    height: 80,
    left: 8,
  },
  outlineIcon: {
    top: 33,
    left: 37,
    borderRadius: 1,
    width: 22,
    height: 15,
    position: "absolute",
  },
  groupItem: {
    top: 5,
    left: 83,
  },
  groupInner: {
    top: 70,
    left: 8,
  },
  text: {
    top: 50,
    left: 0,
  },
  text1: {
    top: 19,
    left: 87,
  },
  ellipseParent: {
    width: 98,
    height: 82,
  },
  failedToRegister: {
    fontSize: FontSize.size_6xl,
    color: Color.colorBlack,
    marginTop: 19,
    textAlign: "center",
    fontFamily: FontFamily.interSemiBold,
    fontWeight: "600",
  },
  sorryYourAccount: {
    color: Color.colorDarkgray,
    marginTop: 19,
    fontFamily: FontFamily.interSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_sm,
  },
  mediumBtnChild: {
    height: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    borderRadius: Border.br_9xs,
    backgroundColor: Color.colorRoyalblue,
    position: "absolute",
    width: "100%",
  },
  mediumBtn: {
    left: 0,
    top: 0,
    position: "absolute",
  },
  tryAgain: {
    marginTop: -9,
    marginLeft: -36,
    fontWeight: "700",
    fontFamily: FontFamily.interBold,
    color: Color.colorWhite,
    left: "50%",
    top: "50%",
    position: "absolute",
  },
  mediumBtnParent: {
    marginTop: 19,
  },
  groupParent: {
    marginTop: -151,
    marginLeft: -115.5,
    alignItems: "center",
    justifyContent: "center",
  },
  faieldRegistration: {
    backgroundColor: Color.colorGhostwhite,
    flex: 1,
    height: 800,
    overflow: "hidden",
    width: "100%",
  },
});

export default FaieldRegistration;
