import * as React from "react";
import { Text, StyleSheet, View, Pressable } from "react-native";
import SectionWithBailsForm from "../components/SectionWithBailsForm";
import { useNavigation } from "@react-navigation/native";
import Section2 from "../components/Section2";
import { Padding, Border, FontSize, FontFamily, Color } from "../GlobalStyles";
import BottomNavigation from "../components/BottomNavigation";
const Orders = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.orders1}>
      <View style={styles.frameParent}>
        <SectionWithBailsForm
          dimensionCode={require("../assets/group-731.png")}
          productCode={require("../assets/group-741.png")}
        />
        <View style={styles.openordersParent}>
          <View style={[styles.openorders, styles.positionsFlexBox]}>
            <Text style={styles.openOrders}>Open Orders</Text>
          </View>
          <Pressable
            style={[styles.positions, styles.positionsFlexBox]}
            onPress={() => navigation.navigate("Orders1")}
          >
            <Text style={styles.openOrders}>Positions</Text>
          </Pressable>
          <View style={[styles.positions, styles.positionsFlexBox]}>
            <Text style={styles.openOrders}>Baskets</Text>
          </View>
          <View style={[styles.positions, styles.positionsFlexBox]}>
            <Text style={styles.openOrders}>GTT</Text>
          </View>
        </View>
      </View>
      <View style={styles.orders1Inner}>
        <View style={[styles.largeBtnParent, styles.largePosition]}>
          <View style={[styles.largeBtnParent, styles.largePosition]}>
            <View style={[styles.largeBtnChild, styles.largePosition]} />
          </View>
          <Text style={[styles.orderHistory, styles.largePosition]}>
            ORDER HISTORY
          </Text>
        </View>
      </View>
      <Section2
        group59={require("../assets/group-592.png")}
        iconDocStarAlt={require("../assets/-icon-doc-star-alt.png")}
        wallet={require("../assets/wallet.png")}
        iconNotes={require("../assets/-icon-notes2.png")}
        iconProfileCircled={require("../assets/-icon-profile-circled.png")}
      />
      <BottomNavigation />
    </View>
    
  );
};

const styles = StyleSheet.create({
  positionsFlexBox: {
    padding: Padding.p_3xs,
    justifyContent: "center",
    height: 20,
    borderRadius: Border.br_9xs,
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  largePosition: {
    left: "50%",
    top: "50%",
    position: "absolute",
  },
  openOrders: {
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.interRegular,
    textAlign: "center",
    color: Color.colorWhite,
  },
  openorders: {
    backgroundColor: Color.colorRoyalblue,
  },
  positions: {
    backgroundColor: Color.colorDarkgray,
    marginLeft: 10,
  },
  openordersParent: {
    alignItems: "flex-end",
    marginTop: 5,
    flexDirection: "row",
    alignSelf: "stretch",
  },
  frameParent: {
    alignSelf: "stretch",
    alignItems: "center",
  },
  largeBtnChild: {
    marginLeft: -150,
    marginTop: -29,
    top: "50%",
    position: "absolute",
    height: 58,
    width: 300,
    backgroundColor: Color.colorRoyalblue,
    borderRadius: Border.br_9xs,
  },
  largeBtnParent: {
    marginLeft: -150,
    marginTop: -29,
    top: "50%",
    position: "absolute",
    height: 58,
    width: 300,
  },
  orderHistory: {
    marginTop: -7,
    marginLeft: -57,
    fontSize: FontSize.size_sm,
    fontWeight: "700",
    fontFamily: FontFamily.interBold,
    top: "50%",
    position: "absolute",
    textAlign: "center",
    color: Color.colorWhite,
  },
  orders1Inner: {
    height: 58,
    width: 300,
  },
  orders1: {
    backgroundColor: Color.colorGhostwhite,
    width: "100%",
    height: 800,
    justifyContent: "space-between",
    alignItems: "center",
    flex: 1,
  },
});

export default Orders;
