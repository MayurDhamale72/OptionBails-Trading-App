import * as React from "react";
import { Text, StyleSheet, View, Pressable } from "react-native";
import { Input } from "@rneui/themed";
import { Image } from "expo-image";
import { FontSize, FontFamily, Border, Color } from "../GlobalStyles";

const SignUp = () => {
  return (
    <View style={styles.signUp1}>
      <View style={styles.frameParent}>
        <View style={styles.letsGetStartedParent}>
          <Text style={styles.letsGetStarted}>Lets Get Started</Text>
          <Text style={[styles.letsTradeThe, styles.letsTradeTheTypo]}>
            Let’s Trade the Game!
          </Text>
        </View>
        <View style={styles.input1Parent}>
          <View style={styles.input1Position}>
            <View style={[styles.input1Child, styles.input1Position]} />
          </View>
          <Input
            value="Sign Up Email"
            inputStyle={{ color: "#aab2bd" }}
            containerStyle={styles.signUpEmailInput}
          />
          <Image
            style={[styles.iconEnvelope, styles.iconPosition]}
            contentFit="cover"
            source={require("../assets/-icon-envelope.png")}
          />
        </View>
        <Text style={[styles.orUseInstatnt, styles.letsTradeTheTypo]}>
          Or Use Instatnt Sighn Up
        </Text>
        <View style={styles.input1Parent}>
          <View style={styles.input1Position}>
            <View style={[styles.input2Child, styles.iconPosition]} />
          </View>
          <Text style={[styles.signWithGoogle, styles.signPosition]}>
            Sign with Google
          </Text>
          <Image
            style={[styles.download3RemovebgPreviewIcon, styles.iconPosition]}
            contentFit="cover"
            source={require("../assets/download--3-removebgpreview-1.png")}
          />
        </View>
        <View style={styles.input1Parent}>
          <View style={styles.input1Position}>
            <View style={[styles.input2Child, styles.iconPosition]} />
          </View>
          <Text style={[styles.signWithFacebook, styles.signPosition]}>
            Sign with Facebook
          </Text>
          <Image
            style={styles.iconFacebook}
            contentFit="cover"
            source={require("../assets/-icon-facebook.png")}
          />
        </View>
        <Text style={[styles.alreadyHaveAnContainer, styles.letsTradeTheTypo]}>
          <Text
            style={styles.alreadyHaveAn}
          >{`Already Have an Account? `}</Text>
          <Text style={styles.signIn}>Sign In</Text>
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  signUpEmailInput: {
    left: "50%",
    marginLeft: -84,
    marginTop: -12,
    top: "50%",
    position: "absolute",
  },
  letsTradeTheTypo: {
    fontSize: FontSize.size_sm,
    textAlign: "center",
    fontFamily: FontFamily.interSemiBold,
    fontWeight: "600",
  },
  input1Position: {
    borderRadius: Border.br_9xs,
    left: "50%",
    top: "50%",
    marginLeft: -150,
    marginTop: -29,
    height: 58,
    width: 300,
    position: "absolute",
  },
  iconPosition: {
    left: "50%",
    top: "50%",
    position: "absolute",
  },
  signPosition: {
    fontSize: FontSize.size_lg,
    marginTop: -12,
    left: "50%",
    top: "50%",
    textAlign: "center",
    color: Color.colorBlack,
    position: "absolute",
  },
  letsGetStarted: {
    fontSize: FontSize.size_6xl,
    textAlign: "center",
    color: Color.colorBlack,
    fontFamily: FontFamily.interSemiBold,
    fontWeight: "600",
  },
  letsTradeThe: {
    marginTop: 32,
    color: Color.colorDarkgray,
  },
  letsGetStartedParent: {
    alignItems: "center",
  },
  input1Child: {
    backgroundColor: Color.colorWhite,
  },
  iconEnvelope: {
    marginTop: -9,
    marginLeft: -131,
    width: 25,
    height: 19,
  },
  input1Parent: {
    marginTop: 33,
    height: 58,
    width: 300,
  },
  orUseInstatnt: {
    marginTop: 33,
    color: Color.colorDarkgray,
  },
  input2Child: {
    borderRadius: Border.br_xs,
    borderStyle: "solid",
    borderColor: Color.colorDarkgray,
    borderWidth: 1.5,
    marginLeft: -150,
    marginTop: -29,
    top: "50%",
    height: 58,
    width: 300,
  },
  signWithGoogle: {
    marginLeft: -72,
    fontFamily: FontFamily.interSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_lg,
    marginTop: -12,
  },
  download3RemovebgPreviewIcon: {
    marginTop: -15,
    marginLeft: -136,
    width: 30,
    height: 30,
  },
  signWithFacebook: {
    marginLeft: -84,
    fontWeight: "700",
    fontFamily: FontFamily.interBold,
  },
  iconFacebook: {
    height: "51.38%",
    width: "10%",
    top: "24.14%",
    right: "85.33%",
    bottom: "24.48%",
    left: "4.67%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  alreadyHaveAn: {
    color: Color.colorDarkgray,
  },
  signIn: {
    color: "#0866ff",
  },
  alreadyHaveAnContainer: {
    marginTop: 33,
  },
  frameParent: {
    top: 174,
    left: 30,
    justifyContent: "center",
    alignItems: "center",
    position: "absolute",
  },
  signUp1: {
    backgroundColor: Color.colorGhostwhite,
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
  },
});

export default SignUp;
