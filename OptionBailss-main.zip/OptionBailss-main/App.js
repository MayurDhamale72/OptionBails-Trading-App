import * as React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { useFonts } from "expo-font";
import SignUp from "./screens/SignUp";
import OTPVerification from "./screens/OTPVerification";
import GroupComponent from "./components/GroupComponent";
import Back from "./components/Back";
import SuccessfullyRegistered from "./screens/SuccessfullyRegistered";
import FaieldRegistration from "./screens/FaieldRegistration";
import SplashScreen from "./screens/SplashScreen";
import MainHomeScreen from "./screens/MainHomeScreen";
import Property1off from "./components/Property1off";
import Property1off1 from "./components/Property1off1";
import Property1off2 from "./components/Property1off2";
import Property1off3 from "./components/Property1off3";
import Property1off4 from "./components/Property1off4";
import Property1on from "./components/Property1on";
import Property1off5 from "./components/Property1off5";
import Property1off6 from "./components/Property1off6";
import Property1off7 from "./components/Property1off7";
import Property1off8 from "./components/Property1off8";
import Statustime from "./components/Statustime";
import Property1mega from "./components/Property1mega";
import Property1on1 from "./components/Property1on1";
import Property1off9 from "./components/Property1off9";
import Property1off10 from "./components/Property1off10";
import Property1off11 from "./components/Property1off11";
import Property1off12 from "./components/Property1off12";
import Orders from "./screens/Orders";
import Orders1 from "./screens/Orders1";
import Portfolio from "./screens/Portfolio";
import CreateWatchlist from "./screens/CreateWatchlist";
import HomePageWinnings from "./screens/HomePageWinnings";
import HomePageCompleted from "./screens/HomePageCompleted";
import HomePageUpcoming from "./screens/HomePageUpcoming";
import HomePageLive from "./screens/HomePageLive";
import HokeyHomePageExplore from "./screens/HokeyHomePageExplore";
import HokeyHomePageWinnings from "./screens/HokeyHomePageWinnings";
import HokeyHomePageCompleted from "./screens/HokeyHomePageCompleted";
import HokeyHomePageUpcoming from "./screens/HokeyHomePageUpcoming";
import HokeyHomePageLive from "./screens/HokeyHomePageLive";
import BaseballHomePageExplore from "./screens/BaseballHomePageExplore";
import BaseballHomePageWinnings from "./screens/BaseballHomePageWinnings";
import BaseballHomePageCompleted from "./screens/BaseballHomePageCompleted";
import BaseballHomePageUpcoming from "./screens/BaseballHomePageUpcoming";
import BaseballHomePageLive from "./screens/BaseballHomePageLive";
import BasketballHomePageExplore from "./screens/BasketballHomePageExplore";
import BasketballHomePageWinnings from "./screens/BasketballHomePageWinnings";
import BasketballHomePageCompleted from "./screens/BasketballHomePageCompleted";
import BasketballHomePageUpcoming from "./screens/BasketballHomePageUpcoming";
import BasketballHomePageLive from "./screens/BasketballHomePageLive";
import FootballHomePageExplore from "./screens/FootballHomePageExplore";
import FootballHomePageWinnings from "./screens/FootballHomePageWinnings";
import FootballHomePageCompleted from "./screens/FootballHomePageCompleted";
import FootballHomePageUpcoming from "./screens/FootballHomePageUpcoming";
import FootballHomePageLive from "./screens/FootballHomePageLive";
import CricketHomePageExplore from "./screens/CricketHomePageExplore";
import CricketHomePageWinnings from "./screens/CricketHomePageWinnings";
import CricketHomePageCompleted from "./screens/CricketHomePageCompleted";
import CricketHomePageUpcoming from "./screens/CricketHomePageUpcoming";
import CricketHomePageLive from "./screens/CricketHomePageLive";
import Otpver from "./screens/Otpver";
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { View, Text, Pressable, TouchableOpacity } from "react-native";

const Stack = createNativeStackNavigator();
const App = () => {
  const [hideSplashScreen, setHideSplashScreen] = React.useState(true);

  const [fontsLoaded, error] = useFonts({
    "Inter-SemiBold": require("./assets/fonts/Inter-SemiBold.ttf"),
    "Inter-Bold": require("./assets/fonts/Inter-Bold.ttf"),
  });

  if (!fontsLoaded && !error) {
    return null;
  }

  return (
    <>
     <GestureHandlerRootView style={{ flex: 1 }}>
      <NavigationContainer>
        {hideSplashScreen ? (
          <Stack.Navigator screenOptions={{ headerShown: false }} initialRouteName="MainHomeScreen">

            <Stack.Screen
              name="SignUp"
              component={SignUp}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="OTPVerification"
              component={OTPVerification}
              options={{ headerShown: false }}
            />

            <Stack.Screen
              name="SuccessfullyRegistered"
              component={SuccessfullyRegistered}
              options={{ headerShown: false }}
            />

            <Stack.Screen
              name="FaieldRegistration"
              component={FaieldRegistration}
              options={{ headerShown: false }}
            />

            <Stack.Screen
              name="Otpver"
              component={Otpver}
              options={{ headerShown: false }}
            />

            <Stack.Screen
              name="MainHomeScreen"
              component={MainHomeScreen}
              options={{ headerShown: false }}
            />

<Stack.Screen
              name="Orders"
              component={Orders}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Orders1"
              component={Orders1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Portfolio"
              component={Portfolio}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CreateWatchlist"
              component={CreateWatchlist}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="HomePageWinnings"
              component={HomePageWinnings}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="HomePageCompleted"
              component={HomePageCompleted}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="HomePageUpcoming"
              component={HomePageUpcoming}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="HomePageLive"
              component={HomePageLive}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="HokeyHomePageExplore"
              component={HokeyHomePageExplore}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="HokeyHomePageWinnings"
              component={HokeyHomePageWinnings}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="HokeyHomePageCompleted"
              component={HokeyHomePageCompleted}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="HokeyHomePageUpcoming"
              component={HokeyHomePageUpcoming}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="HokeyHomePageLive"
              component={HokeyHomePageLive}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="BaseballHomePageExplore"
              component={BaseballHomePageExplore}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="BaseballHomePageWinnings"
              component={BaseballHomePageWinnings}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="BaseballHomePageCompleted"
              component={BaseballHomePageCompleted}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="BaseballHomePageUpcoming"
              component={BaseballHomePageUpcoming}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="BaseballHomePageLive"
              component={BaseballHomePageLive}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="BasketballHomePageExplore"
              component={BasketballHomePageExplore}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="BasketballHomePageWinnings"
              component={BasketballHomePageWinnings}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="BasketballHomePageCompleted"
              component={BasketballHomePageCompleted}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="BasketballHomePageUpcoming"
              component={BasketballHomePageUpcoming}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="BasketballHomePageLive"
              component={BasketballHomePageLive}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="FootballHomePageExplore"
              component={FootballHomePageExplore}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="FootballHomePageWinnings"
              component={FootballHomePageWinnings}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="FootballHomePageCompleted"
              component={FootballHomePageCompleted}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="FootballHomePageUpcoming"
              component={FootballHomePageUpcoming}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="FootballHomePageLive"
              component={FootballHomePageLive}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CricketHomePageExplore"
              component={CricketHomePageExplore}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CricketHomePageWinnings"
              component={CricketHomePageWinnings}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CricketHomePageCompleted"
              component={CricketHomePageCompleted}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CricketHomePageUpcoming"
              component={CricketHomePageUpcoming}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CricketHomePageLive"
              component={CricketHomePageLive}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SplashScreen"
              component={SplashScreen}
              options={{ headerShown: false }}
            />

          </Stack.Navigator>
        ) : null}
      </NavigationContainer>
      </GestureHandlerRootView>
    </>
  );
};
export default App;
